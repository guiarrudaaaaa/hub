# DHL Operations Hub 2026

Aplicação web interna para gestão de dados operacionais de inbound, outbound e inventário da operação logística do Centro de Distribuição.

## Estrutura base

- `index.html`: ponto de entrada da aplicação
- `css/`: design system e layout
- `js/`: módulos da aplicação, serviços, utilitários e roteamento
- `tests/`: testes automatizados de utilitários e regras de negócio
- `docs/`: documentação e arquitetura

## Execução local

A aplicação foi construída para rodar em um servidor estático simples. Para iniciar localmente:

```bash
cd dhl-operations-hub
python -m http.server 4173
```

Acesse em: http://localhost:4173

## Observações

- A implementação atual cobre a base da Fase 1: design system, navegação, layout, rotas e utilitários de negócio.
- Dados reais e importação funcional serão entregues nas fases seguintes.
- Nenhum dado fictício foi incorporado ao app; os estados vazios são usados até a importação.
