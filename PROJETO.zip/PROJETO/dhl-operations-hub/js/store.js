export function createStore(initialState = {}) {
  const state = { ...initialState };
  const listeners = new Set();

  return {
    getState() {
      return { ...state };
    },
    setState(patch) {
      Object.assign(state, patch);
      listeners.forEach((listener) => listener({ ...state }));
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

const STORAGE_KEY = 'dhl-operations-hub-state';

function readPersistedState() {
  if (typeof window === 'undefined' || !window.localStorage) {
    return {};
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function createAppStore(initialState = {}) {
  const persisted = readPersistedState();
  const store = createStore({
    importJobs: [],
    recordsByOperation: {
      inbound: [],
      outbound: [],
      inventory: []
    },
    lastImportSummary: null,
    userRole: 'admin',
    ...persisted,
    ...initialState
  });

  function persistSnapshot() {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store.getState()));
    }
  }

  const baseSetState = store.setState.bind(store);
  store.setState = (patch) => {
    baseSetState(patch);
    persistSnapshot();
  };

  return {
    ...store,
    appendImportJob(job) {
      const nextJobs = [job, ...store.getState().importJobs];
      const recordsByOperation = { ...store.getState().recordsByOperation };

      if (Array.isArray(job.records)) {
        const operationKey = String(job.operation || 'inbound');
        recordsByOperation[operationKey] = [
          ...(recordsByOperation[operationKey] || []),
          ...job.records
        ];
      }

      store.setState({ importJobs: nextJobs, lastImportSummary: job, recordsByOperation });
      return nextJobs;
    },
    setImportSummary(summary) {
      store.setState({ lastImportSummary: summary });
      return summary;
    }
  };
}

export const appStore = createAppStore();
