export function buildIndicatorsState() {
  return {
    hasData: false,
    title: 'Indicadores',
    status: 'empty'
  };
}
