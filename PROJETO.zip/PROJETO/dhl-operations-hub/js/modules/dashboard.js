export function buildDashboardState() {
  return {
    hasData: false,
    title: 'Dashboard',
    status: 'empty'
  };
}
