import { buildHashWithQuery, resolveRoute, routeMap } from './router.js';
import { getCurrentUser } from './services/auth.js';
import { initFirebase } from './firebase-config.js';
import { getTurnoByHour } from './utils/date-utils.js';
import { renderImportWizard, bindImportWizard } from './import-wizard.js';
import { appStore } from './store.js';
import { readFilterStateFromHash, applyFilterStateToControls, writeFilterStateToHash } from './utils/filter-state.js';
import { parseNumber, summarizeOperation, buildImportHistorySummary } from './utils/metrics.js';
import { renderChartCard } from './components/chart-card.js';
import { enhanceEmptyStates } from './components/feedback.js';
import { filterRecordsBySearch, normalizeSearchText, searchRecords } from './utils/search.js';

const app = document.getElementById('app');
const navButtons = [...document.querySelectorAll('.nav-item')];
const commandPalette = document.getElementById('commandPalette');
const commandInput = document.getElementById('commandInput');
const commandList = document.getElementById('commandList');
const globalSearch = document.getElementById('globalSearch');
const globalSearchResults = document.getElementById('globalSearchResults');
const toggleSidebar = document.getElementById('toggleSidebar');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const tvModeButton = document.getElementById('tvModeButton');
const tvRoutes = ['/overview', '/indicators', '/inbound', '/outbound', '/inventory', '/productivity', '/turnos', '/history'];
const tvRotationIntervalMs = 15000;

const currentUser = getCurrentUser();
const firebaseStatus = initFirebase();
let tvRotationTimer = null;
let activeCommandIndex = -1;
let activeSearchIndex = -1;
let commandPaletteReturnFocus = null;

function initializeKpiCards() {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  app.querySelectorAll('.kpi-card').forEach((card) => {
    const value = card.querySelector('.kpi-value');
    const trend = card.querySelector('.kpi-trend');

    if (!value || !trend) return;

    const history = document.createElement('div');
    history.className = 'kpi-history';

    const availability = document.createElement('span');
    availability.className = 'kpi-change';
    availability.textContent = 'Sem histórico';

    const sparkline = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    sparkline.classList.add('kpi-sparkline');
    sparkline.setAttribute('viewBox', '0 0 80 24');
    sparkline.setAttribute('aria-hidden', 'true');
    sparkline.setAttribute('focusable', 'false');

    const line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    line.setAttribute('points', '3,12 15,12 27,12 39,12 51,12 63,12 75,12');
    sparkline.append(line);

    history.append(availability, sparkline);
    trend.after(history);

    const numericValue = value.textContent.trim().match(/^(-?\d+(?:[.,]\d+)?)(\s*(?:%|t)?)$/i);
    if (!numericValue) {
      value.classList.add('kpi-value-text');
      return;
    }

    if (prefersReducedMotion) return;

    const target = Number(numericValue[1].replace(',', '.'));
    if (!Number.isFinite(target)) return;

    const originalValue = value.textContent;
    const decimalPlaces = numericValue[1].split(/[.,]/)[1]?.length ?? 0;
    const suffix = numericValue[2];
    const startTime = performance.now();
    const duration = 800;

    function animateValue(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const easedProgress = 1 - ((1 - progress) ** 3);
      value.textContent = `${(target * easedProgress).toFixed(decimalPlaces)}${suffix}`;

      if (progress < 1) {
        requestAnimationFrame(animateValue);
      } else {
        value.textContent = originalValue;
      }
    }

    value.textContent = `0${decimalPlaces ? `.${'0'.repeat(decimalPlaces)}` : ''}${suffix}`;
    requestAnimationFrame(animateValue);
  });
}

function initializeDataModeBadge() {
  const heading = app.querySelector('.page-header h2');
  if (!heading) return;

  const titleRow = document.createElement('div');
  titleRow.className = 'page-title-row';

  const badge = document.createElement('span');
  badge.className = 'data-mode-badge';
  badge.setAttribute('aria-label', 'Os dados são armazenados localmente neste navegador');
  badge.textContent = 'MODO LOCAL';

  heading.replaceWith(titleRow);
  titleRow.append(heading, badge);
}

function initializeLucideIcons() {
  if (!window.lucide?.createIcons) {
    console.error('Lucide não carregou; a navegação permanece disponível pelos rótulos.');
    return;
  }

  window.lucide.createIcons();
}

function advanceTvRoute() {
  const currentRoute = resolveRoute(window.location.hash || '#/overview').route;
  const currentIndex = tvRoutes.indexOf(currentRoute);
  const nextRoute = tvRoutes[(currentIndex + 1 + tvRoutes.length) % tvRoutes.length];
  window.location.hash = `#${nextRoute}`;
}

function setTvMode(enabled) {
  document.body.classList.toggle('tv-mode', enabled);
  document.body.style.filter = enabled ? 'brightness(1.06)' : 'none';
  tvModeButton.setAttribute('aria-pressed', String(enabled));

  if (tvRotationTimer !== null) {
    window.clearInterval(tvRotationTimer);
    tvRotationTimer = null;
  }

  if (!enabled) return;

  const currentRoute = resolveRoute(window.location.hash || '#/overview').route;
  if (!tvRoutes.includes(currentRoute)) {
    window.location.hash = '#/overview';
  }

  tvRotationTimer = window.setInterval(advanceTvRoute, tvRotationIntervalMs);
}

function getRecordShift(record) {
  const shift = String(record.turno ?? record.turnoOperacional ?? record.turnoOp ?? '')
    .trim()
    .toUpperCase();
  return ['T1', 'T2', 'T3'].includes(shift) ? shift : null;
}

function collectShiftRecords() {
  return Object.entries(appStore.getState().recordsByOperation).flatMap(([operation, records]) =>
    (Array.isArray(records) ? records : [])
      .map((record) => ({ operation, record, turno: getRecordShift(record) }))
      .filter((entry) => entry.turno)
  );
}

function summarizeShiftRecords(records) {
  const shifts = ['T1', 'T2', 'T3'].map((turno) => ({
    turno,
    totalRows: 0,
    totalTon: 0,
    tonnageRows: 0
  }));

  records.forEach(({ operation, record, turno }) => {
    const shift = shifts.find((entry) => entry.turno === turno);
    if (!shift) return;

    shift.totalRows += 1;
    if (operation !== 'inventory' && hasValue(record, 'toneladas')) {
      shift.totalTon += parseNumber(record.toneladas);
      shift.tonnageRows += 1;
    }
  });

  return {
    shifts,
    peakShift: [...shifts].filter((shift) => shift.totalRows).sort((a, b) => b.totalRows - a.totalRows)[0] ?? null,
    totalRows: shifts.reduce((sum, shift) => sum + shift.totalRows, 0)
  };
}

function hasValue(record, field) {
  const value = record[field];
  return value !== undefined && value !== null && String(value).trim() !== '';
}

function sumRecordField(records, field) {
  return records.reduce((sum, record) => sum + parseNumber(record[field] ?? 0), 0);
}

function getExecutiveMetrics(recordState) {
  const inbound = Array.isArray(recordState.inbound) ? recordState.inbound : [];
  const outbound = Array.isArray(recordState.outbound) ? recordState.outbound : [];
  const inventory = Array.isArray(recordState.inventory) ? recordState.inventory : [];
  const accuracyRecords = inventory.filter((record) => hasValue(record, 'acuracia'));
  const inventorySummary = accuracyRecords.length
    ? summarizeOperation(accuracyRecords, 'inventory')
    : null;
  const tonnageRecords = [...inbound, ...outbound].filter((record) => hasValue(record, 'toneladas'));
  const slaRecords = [...inbound, ...outbound].filter(
    (record) => hasValue(record, 'slaStatus') || hasValue(record, 'status')
  );
  const slaSummary = slaRecords.length ? summarizeOperation(slaRecords, 'inbound') : null;
  const tonnageEntries = [
    { operation: 'inbound', records: inbound },
    { operation: 'outbound', records: outbound }
  ].filter((entry) => entry.records.some((record) => hasValue(record, 'toneladas')));
  const bestTonnageOperation = [...tonnageEntries]
    .map((entry) => ({ ...entry, totalTon: sumRecordField(entry.records, 'toneladas') }))
    .sort((a, b) => b.totalTon - a.totalTon)[0] ?? null;

  return {
    inbound,
    outbound,
    inventory,
    inventorySummary,
    totalRecords: inbound.length + outbound.length + inventory.length,
    totalTons: sumRecordField([...inbound, ...outbound], 'toneladas'),
    hasTonnageData: tonnageRecords.length > 0,
    slaSummary,
    accuracyRecords,
    bestTonnageOperation
  };
}

const oneDecimalFormatter = new Intl.NumberFormat('pt-BR', {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1
});

function formatTons(value) {
  return `${oneDecimalFormatter.format(value)} t`;
}

function renderMetricBars(entries) {
  const maxValue = Math.max(0, ...entries.map((entry) => Math.abs(entry.value)));
  const rows = entries.map((entry) => {
    const width = maxValue ? (Math.abs(entry.value) / maxValue) * 100 : 0;
    return `
      <div class="metric-bar-row" role="listitem" aria-label="${entry.label}: ${entry.display}">
        <div class="metric-bar-label">
          <span>${entry.label}</span>
          <strong>${entry.display}</strong>
        </div>
        <div class="metric-bar-track" aria-hidden="true">
          <span class="metric-bar-fill ${entry.className || ''}" style="width: ${width.toFixed(1)}%"></span>
        </div>
      </div>
    `;
  }).join('');

  return `<div class="metric-bars" role="list">${rows}</div>`;
}

function renderTonnageBalanceChart(recordState) {
  const inbound = Array.isArray(recordState.inbound) ? recordState.inbound : [];
  const outbound = Array.isArray(recordState.outbound) ? recordState.outbound : [];
  const hasInboundTonnage = inbound.some((record) => hasValue(record, 'toneladas'));
  const hasOutboundTonnage = outbound.some((record) => hasValue(record, 'toneladas'));

  if (!hasInboundTonnage && !hasOutboundTonnage) {
    return '<div class="metric-chart-empty" role="status">Não há toneladas informadas em registros Inbound ou Outbound.</div>';
  }

  const inboundTons = sumRecordField(inbound, 'toneladas');
  const outboundTons = sumRecordField(outbound, 'toneladas');
  const balance = inboundTons - outboundTons;
  return renderMetricBars([
    {
      label: 'Inbound',
      value: hasInboundTonnage ? inboundTons : 0,
      display: hasInboundTonnage ? formatTons(inboundTons) : 'N/A',
      className: hasInboundTonnage ? 'inbound' : 'no-data'
    },
    {
      label: 'Outbound',
      value: hasOutboundTonnage ? outboundTons : 0,
      display: hasOutboundTonnage ? formatTons(outboundTons) : 'N/A',
      className: hasOutboundTonnage ? 'outbound' : 'no-data'
    },
    {
      label: 'Saldo líquido',
      value: hasInboundTonnage && hasOutboundTonnage ? balance : 0,
      display: hasInboundTonnage && hasOutboundTonnage
        ? `${balance > 0 ? '+' : ''}${formatTons(balance)}`
        : 'N/A',
      className: hasInboundTonnage && hasOutboundTonnage
        ? (balance < 0 ? 'balance-negative' : 'balance')
        : 'no-data'
    }
  ]);
}

function renderShiftDistributionChart(records) {
  const shiftSummary = summarizeShiftRecords(records);

  if (!shiftSummary.totalRows) {
    return '<div class="metric-chart-empty" role="status">Os registros ainda não informam um turno operacional.</div>';
  }

  return renderMetricBars(shiftSummary.shifts.map((shift) => ({
    label: shift.turno,
    value: shift.totalRows,
    display: `${shift.totalRows} ${shift.totalRows === 1 ? 'registro' : 'registros'}`,
    className: 'shift'
  })));
}

function renderOperationCountChart(metrics) {
  const entries = [
    { label: 'Inbound', value: metrics.inbound.length, className: 'inbound' },
    { label: 'Outbound', value: metrics.outbound.length, className: 'outbound' },
    { label: 'Inventário', value: metrics.inventory.length, className: 'inventory' }
  ];

  return renderMetricBars(entries.map((entry) => ({
    ...entry,
    display: `${entry.value} ${entry.value === 1 ? 'registro' : 'registros'}`
  })));
}

function renderOverviewPage() {
  const recordState = appStore.getState().recordsByOperation;
  const metrics = getExecutiveMetrics(recordState);

  if (!metrics.totalRecords) {
    return `
      <section class="page-card">
        <div class="page-header">
          <div>
            <p class="eyebrow">Painel executivo</p>
            <h2>Visão Geral</h2>
          </div>
          <span class="status-badge warning">Aguardando importação</span>
        </div>

        <div class="empty-state">
          <div>
            <h3>Sem dados para exibir</h3>
            <p>Os KPIs e os insights só aparecerão após a importação e validação dos registros operacionais.</p>
          </div>
        </div>
      </section>
    `;
  }

  const charts = [
    renderChartCard(
      'Saldo de toneladas',
      'Comparação entre os registros Inbound e Outbound',
      renderTonnageBalanceChart(recordState),
      'O saldo só é calculado quando há tonelagem informada nas duas operações.'
    ),
    renderChartCard(
      'Registros por turno',
      'Distribuição dos registros com turno informado',
      renderShiftDistributionChart(collectShiftRecords()),
      'São considerados apenas registros com turno T1, T2 ou T3 informado.'
    )
  ].join('');

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Painel executivo</p>
          <h2>Visão Geral</h2>
        </div>
        <span class="status-badge success">Dados importados: ${metrics.totalRecords}</span>
      </div>

      <div class="page-kpis">
        <article class="kpi-card">
          <div class="kpi-label"><span>Registros</span><span>total</span></div>
          <div class="kpi-value">${metrics.totalRecords}</div>
          <div class="kpi-trend">Base consolidada</div>
        </article>

        <article class="kpi-card">
          <div class="kpi-label"><span>Toneladas</span><span>somadas</span></div>
          <div class="kpi-value">${metrics.hasTonnageData ? formatTons(metrics.totalTons) : 'N/A'}</div>
          <div class="kpi-trend ${metrics.hasTonnageData ? '' : 'muted'}">${metrics.hasTonnageData ? `${formatTons(sumRecordField(metrics.inbound, 'toneladas'))} Inbound · ${formatTons(sumRecordField(metrics.outbound, 'toneladas'))} Outbound` : 'Sem tonelagem informada'}</div>
        </article>

        <article class="kpi-card">
          <div class="kpi-label"><span>SLA</span><span>efetivo</span></div>
          <div class="kpi-value">${metrics.slaSummary ? `${metrics.slaSummary.slaRate.toFixed(1)}%` : 'N/A'}</div>
          <div class="kpi-trend ${metrics.slaSummary ? '' : 'muted'}">${metrics.slaSummary ? `${metrics.slaSummary.totalRows} registros com status` : 'Sem status de SLA informado'}</div>
        </article>

        <article class="kpi-card">
          <div class="kpi-label"><span>Acuracidade</span><span>inventário</span></div>
          <div class="kpi-value">${metrics.inventorySummary ? `${metrics.inventorySummary.accuracy.toFixed(1)}%` : 'N/A'}</div>
          <div class="kpi-trend ${metrics.inventorySummary ? (metrics.inventorySummary.accuracy < 99 ? 'negative' : '') : 'muted'}">${metrics.inventorySummary ? `${metrics.accuracyRecords.length} itens com acurácia` : 'Sem acurácia informada'}</div>
        </article>
      </div>
    </section>

    <section class="page-grid">
      ${charts}
    </section>
  `;
}

function renderProductivityPage() {
  const recordState = appStore.getState().recordsByOperation;
  const metrics = getExecutiveMetrics(recordState);

  if (!metrics.totalRecords) {
    return `
      <section class="page-card">
        <div class="page-header">
          <div>
            <p class="eyebrow">Produtividade</p>
            <h2>Rendimento Operacional</h2>
          </div>
          <span class="status-badge warning">Base vazia</span>
        </div>
        <div class="empty-state">
          <div>
            <h3>Sem produtividade para medir</h3>
            <p>Os indicadores de throughput e eficiência só aparecem após a primeira importação de registros válidos.</p>
          </div>
        </div>
      </section>
    `;
  }

  const peakOperation = metrics.bestTonnageOperation?.operation.toUpperCase() || 'N/A';

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Produtividade</p>
          <h2>Rendimento Operacional</h2>
        </div>
        <span class="status-badge success">${metrics.totalRecords} registros</span>
      </div>

      <div class="page-kpis">
        <article class="kpi-card"><div class="kpi-label"><span>Registros</span><span>ativos</span></div><div class="kpi-value">${metrics.totalRecords}</div><div class="kpi-trend">base consolidada</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Toneladas</span><span>movimentadas</span></div><div class="kpi-value">${metrics.hasTonnageData ? formatTons(metrics.totalTons) : 'N/A'}</div><div class="kpi-trend ${metrics.hasTonnageData ? '' : 'muted'}">${metrics.hasTonnageData ? 'Inbound + Outbound' : 'Sem tonelagem informada'}</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Operação</span><span>maior volume</span></div><div class="kpi-value">${peakOperation}</div><div class="kpi-trend ${metrics.bestTonnageOperation ? '' : 'muted'}">${metrics.bestTonnageOperation ? 'por tonelagem informada' : 'Sem dados de tonelagem'}</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>SLA médio</span><span>operações</span></div><div class="kpi-value">${metrics.slaSummary ? `${metrics.slaSummary.slaRate.toFixed(1)}%` : 'N/A'}</div><div class="kpi-trend ${metrics.slaSummary ? '' : 'muted'}">${metrics.slaSummary ? `${metrics.slaSummary.totalRows} registros com status` : 'Sem status de SLA informado'}</div></article>
      </div>
    </section>

    <section class="page-grid">
      ${renderChartCard('Registros por operação', 'Volume de registros em cada módulo', renderOperationCountChart(metrics), 'Contagem da base importada por operação.')}
      ${renderChartCard('Registros por turno', 'Distribuição dos registros com turno informado', renderShiftDistributionChart(collectShiftRecords()), 'São considerados apenas registros com turno T1, T2 ou T3 informado.')}
    </section>
  `;
}

function renderTurnosPage() {
  const shiftSummary = summarizeShiftRecords(collectShiftRecords());

  if (!shiftSummary.totalRows) {
    return `
      <section class="page-card">
        <div class="page-header">
          <div>
            <p class="eyebrow">Turnos</p>
            <h2>Performance por Turno</h2>
          </div>
          <span class="status-badge warning">Sem dados</span>
        </div>
        <div class="empty-state">
          <div>
            <h3>Base ainda vazia</h3>
            <p>O desempenho por turno será montado após a primeira carga operacional com registros válidos e turno definido.</p>
          </div>
        </div>
      </section>
    `;
  }

  const rows = shiftSummary.shifts.map((entry) => `
    <tr>
      <td>${entry.turno}</td>
      <td>${entry.totalRows}</td>
      <td>${entry.tonnageRows ? formatTons(entry.totalTon) : 'N/A'}</td>
      <td>${entry.tonnageRows ? `${oneDecimalFormatter.format(entry.totalTon / entry.tonnageRows)} t/reg. com tonelagem` : 'N/A'}</td>
    </tr>
  `).join('');

  return `
    <section class="page-card">
      <div class="page-header">
        <div><p class="eyebrow">Turnos</p><h2>Performance por Turno</h2></div>
        <span class="status-badge success">Turno pico: ${shiftSummary.peakShift ? shiftSummary.peakShift.turno : 'N/A'}</span>
      </div>

      <div class="page-kpis">
        ${shiftSummary.shifts.map((entry) => `
          <article class="kpi-card">
            <div class="kpi-label"><span>${entry.turno}</span><span>registro</span></div>
            <div class="kpi-value">${entry.totalRows}</div>
            <div class="kpi-trend ${entry.tonnageRows ? '' : 'muted'}">${entry.tonnageRows ? formatTons(entry.totalTon) : 'Sem tonelagem informada'}</div>
          </article>
        `).join('')}
      </div>

      <div class="import-preview-table" style="margin-top: 24px;">
        <table>
          <thead><tr><th>Turno</th><th>Registros</th><th>Toneladas</th><th>t / reg. com tonelagem</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </section>
  `;
}

function renderHistoryPage() {
  const importJobs = appStore.getState().importJobs;
  const summary = buildImportHistorySummary(importJobs);

  if (!importJobs.length) {
    return `
      <section class="page-card">
        <div class="page-header">
          <div>
            <p class="eyebrow">Histórico</p>
            <h2>Análise Histórica</h2>
          </div>
          <span class="status-badge warning">Sem histórico</span>
        </div>
        <div class="empty-state">
          <div>
            <h3>Sem histórico de processo</h3>
            <p>O histórico analítico é alimentado na primeira importação válida do ambiente operacional.</p>
          </div>
        </div>
      </section>
    `;
  }

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Histórico</p>
          <h2>Análise Histórica</h2>
        </div>
        <span class="status-badge success">${summary.totalJobs} importações</span>
      </div>

      <div class="page-kpis">
        <article class="kpi-card"><div class="kpi-label"><span>Válidos</span><span>total</span></div><div class="kpi-value">${summary.validRows}</div><div class="kpi-trend">aceitação</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Inválidos</span><span>total</span></div><div class="kpi-value">${summary.invalidRows}</div><div class="kpi-trend">reprocesso</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Duplicados</span><span>total</span></div><div class="kpi-value">${summary.duplicates}</div><div class="kpi-trend">deduplicados</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Aceitação</span><span>média</span></div><div class="kpi-value">${summary.acceptanceRate.toFixed(1)}%</div><div class="kpi-trend">${summary.latestStatus}</div></article>
      </div>

      <div class="import-preview-table" style="margin-top: 24px;">
        <table>
          <thead>
            <tr><th>Operação</th><th>Status</th><th>Válidos</th><th>Inválidos</th><th>Duplicados</th><th>Atualizações</th></tr>
          </thead>
          <tbody>
            ${importJobs.map((job) => `
              <tr>
                <td>${job.operation}</td>
                <td>${job.status}</td>
                <td>${job.validRows}</td>
                <td>${job.invalidRows}</td>
                <td>${job.duplicates}</td>
                <td>${job.updates}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </section>
  `;
}

function renderSettingsPage() {
  return `
    <section class="page-card">
      <div class="page-header">
        <div><p class="eyebrow">Sistema</p><h2>Configurações</h2></div>
        <span class="status-badge ${firebaseStatus.enabled ? 'success' : 'warning'}">${firebaseStatus.enabled ? 'Firebase ativo' : 'Modo local'}</span>
      </div>

      <div class="page-grid">
        ${renderChartCard('Armazenamento', 'Persistência dos dados', '<div class="settings-summary"><strong>Neste navegador</strong><p>Os registros importados ficam salvos localmente e não são sincronizados com uma base remota.</p></div>', 'Para remover esses dados, limpe os dados deste site nas configurações do navegador.')}
        ${renderChartCard('Importação', 'Arquivos suportados', '<div class="settings-summary"><strong>CSV e Excel</strong><p>O CSV é processado localmente. A leitura de XLSX carrega a biblioteca necessária quando o recurso é usado.</p></div>', 'Nenhuma conexão Firebase está ativa neste ambiente de desenvolvimento.')}
      </div>
    </section>
  `;
}

function renderUsersPage() {
  return `
    <section class="page-card">
      <div class="page-header">
        <div><p class="eyebrow">Administração</p><h2>Usuários e Acesso</h2></div>
        <span class="status-badge success">${currentUser.role}</span>
      </div>

      <div class="page-kpis">
        <article class="kpi-card"><div class="kpi-label"><span>Usuário local</span><span>ambiente</span></div><div class="kpi-value">${currentUser.name}</div><div class="kpi-trend">${currentUser.email}</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Perfil</span><span>local</span></div><div class="kpi-value">${currentUser.role}</div><div class="kpi-trend">Sessão de desenvolvimento</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Auditoria</span><span>central</span></div><div class="kpi-value">N/A</div><div class="kpi-trend muted">Sem serviço de auditoria conectado</div></article>
      </div>
    </section>
  `;
}

function renderIndicatorsPage() {
  const recordState = appStore.getState().recordsByOperation;
  const metrics = getExecutiveMetrics(recordState);

  if (!metrics.totalRecords) {
    return `
      <section class="page-card">
        <div class="page-header">
          <div>
            <p class="eyebrow">Indicadores</p>
            <h2>Central de Indicadores</h2>
          </div>
          <span class="status-badge warning">Base vazia</span>
        </div>

        <div class="empty-state">
          <div>
            <h3>Central sem dados</h3>
            <p>Os indicadores e gráficos aparecerão após a primeira importação de registros operacionais.</p>
          </div>
        </div>
      </section>
    `;
  }

  const charts = [
    renderChartCard(
      'Saldo de toneladas',
      'Comparação entre os registros Inbound e Outbound',
      renderTonnageBalanceChart(recordState),
      'O saldo só é calculado quando há tonelagem informada nas duas operações.'
    ),
    renderChartCard(
      'Registros por turno',
      'Distribuição dos registros com turno informado',
      renderShiftDistributionChart(collectShiftRecords()),
      'São considerados apenas registros com turno T1, T2 ou T3 informado.'
    )
  ].join('');

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Indicadores</p>
          <h2>Central de Indicadores</h2>
        </div>
        <span class="status-badge success">${metrics.totalRecords} registros ativos</span>
      </div>

      <div class="page-kpis">
        <article class="kpi-card"><div class="kpi-label"><span>Registros</span><span>base</span></div><div class="kpi-value">${metrics.totalRecords}</div><div class="kpi-trend">base consolidada</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Toneladas</span><span>Inbound + Outbound</span></div><div class="kpi-value">${metrics.hasTonnageData ? formatTons(metrics.totalTons) : 'N/A'}</div><div class="kpi-trend ${metrics.hasTonnageData ? '' : 'muted'}">${metrics.hasTonnageData ? 'Soma das toneladas informadas' : 'Sem tonelagem informada'}</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>SLA</span><span>médio</span></div><div class="kpi-value">${metrics.slaSummary ? `${metrics.slaSummary.slaRate.toFixed(1)}%` : 'N/A'}</div><div class="kpi-trend ${metrics.slaSummary ? '' : 'muted'}">${metrics.slaSummary ? `${metrics.slaSummary.totalRows} registros com status` : 'Sem status de SLA informado'}</div></article>
        <article class="kpi-card"><div class="kpi-label"><span>Acurácia</span><span>inventário</span></div><div class="kpi-value">${metrics.inventorySummary ? `${metrics.inventorySummary.accuracy.toFixed(1)}%` : 'N/A'}</div><div class="kpi-trend ${metrics.inventorySummary ? '' : 'muted'}">${metrics.inventorySummary ? `${metrics.accuracyRecords.length} itens com acurácia` : 'Sem acurácia informada'}</div></article>
      </div>
    </section>

    <section class="page-grid">
      ${charts}
    </section>
  `;
}

function renderImportHistoryPage() {
  const jobs = appStore.getState().importJobs;

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Histórico</p>
          <h2>Histórico de Importações</h2>
        </div>
        <span class="status-badge success">${jobs.length || 0} job(s)</span>
      </div>

      ${jobs.length ? `
        <div class="import-preview-table">
          <table>
            <thead>
              <tr>
                <th>Operação</th>
                <th>Status</th>
                <th>Válidos</th>
                <th>Inválidos</th>
                <th>Duplicados</th>
                <th>Atualizações</th>
              </tr>
            </thead>
            <tbody>
              ${jobs.map((job) => `
                <tr>
                  <td>${job.operation}</td>
                  <td>${job.status}</td>
                  <td>${job.validRows}</td>
                  <td>${job.invalidRows}</td>
                  <td>${job.duplicates}</td>
                  <td>${job.updates}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : `
        <div class="empty-state">
          <div>
            <h3>Sem importações registradas</h3>
            <p>A base de histórico ficará disponível após a primeira validação de arquivo.</p>
          </div>
        </div>
      `}
    </section>
  `;
}

function renderOperationTable(operation, records) {
  if (!records.length) {
    return `
      <div class="empty-state">
        <div>
          <h3>Sem registros</h3>
          <p>Não há registros importados para esta operação. Faça a importação para popular a tabela.</p>
        </div>
      </div>
    `;
  }

  const headers = {
    inbound: ['Data', 'DT', 'Turno', 'Veículo', 'Toneladas', 'SLA'],
    outbound: ['Data', 'DT', 'Turno', 'Veículo', 'Toneladas', 'Status'],
    inventory: ['Data', 'SKU', 'Endereço', 'Qtd. Física', 'Divergência', 'Status']
  }[operation] || ['Data', 'Resumo'];

  const rows = records.slice(0, 8).map((record) => {
    if (operation === 'inventory') {
      return [
        record.dataOperacional || record.data || '—',
        record.sku || '—',
        record.endereco || '—',
        record.qtdFisica ?? '—',
        record.divergencia ?? '—',
        record.status || 'pendente'
      ];
    }

    return [
      record.dataOperacional || record.data || '—',
      record.dt || '—',
      record.turno || '—',
      record.veiculo || '—',
      record.toneladas ?? '—',
      record.slaStatus || record.status || 'pendente'
    ];
  });

  return `
    <div class="import-preview-table">
      <table>
        <thead>
          <tr>${headers.map((header) => `<th>${header}</th>`).join('')}</tr>
        </thead>
        <tbody>
          ${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderOperationPage(operation, displayName, searchTerm = '') {
  const allRecords = appStore.getState().recordsByOperation[operation] || [];
  const records = filterRecordsBySearch(allRecords, searchTerm);

  if (!records.length) {
    const isSearchEmpty = Boolean(searchTerm);
    return `
      <section class="page-card">
        <div class="page-header">
          <div><p class="eyebrow">Operação</p><h2>${displayName}</h2></div>
          <span class="status-badge warning">${isSearchEmpty ? '0 resultados' : 'Sem dados'}</span>
        </div>
        <div class="${isSearchEmpty ? 'search-no-results' : 'empty-state'}"><div><h3>${isSearchEmpty ? 'Nenhum registro corresponde à busca' : `${displayName} sem registros`}</h3><p>${isSearchEmpty ? 'Tente outro termo ou limpe a busca.' : 'Importe arquivos para alimentar esta operação e gerar KPIs e tabela.'}</p>${isSearchEmpty ? `<a class="secondary-button" href="#/${operation}">Limpar busca</a>` : ''}</div></div>
      </section>
    `;
  }

  const kpis = operation === 'inventory'
    ? [
      ['Registros', String(records.length)],
      ['Qtd. sistêmica', records.some((record) => hasValue(record, 'qtdSistemica'))
        ? new Intl.NumberFormat('pt-BR').format(sumRecordField(records, 'qtdSistemica'))
        : 'N/A'],
      ['Acurácia', records.some((record) => hasValue(record, 'acuracia'))
        ? `${summarizeOperation(records.filter((record) => hasValue(record, 'acuracia')), 'inventory').accuracy.toFixed(1)}%`
        : 'N/A'],
      ['Itens divergentes', String(records.filter((record) => parseNumber(record.divergencia) !== 0).length)]
    ]
    : [
      ['Registros', String(records.length)],
      ['Toneladas', records.some((record) => hasValue(record, 'toneladas'))
        ? formatTons(sumRecordField(records, 'toneladas'))
        : 'N/A'],
      ['SLA', records.some((record) => hasValue(record, 'slaStatus') || hasValue(record, 'status'))
        ? `${summarizeOperation(records.filter((record) => hasValue(record, 'slaStatus') || hasValue(record, 'status')), operation).slaRate.toFixed(1)}%`
        : 'N/A'],
      [operation === 'outbound' ? 'Volumes' : 'Pallets', records.some((record) => hasValue(record, operation === 'outbound' ? 'volumes' : 'pallets'))
        ? new Intl.NumberFormat('pt-BR').format(sumRecordField(records, operation === 'outbound' ? 'volumes' : 'pallets'))
        : 'N/A']
    ];

  return `
    <section class="page-card">
      <div class="page-header">
        <div><p class="eyebrow">Operação</p><h2>${displayName}</h2></div>
        <span class="status-badge success">${records.length} ${searchTerm ? (records.length === 1 ? 'resultado' : 'resultados') : 'registros ativos'}</span>
      </div>

      <div class="page-kpis">
        ${kpis.map(([label, value]) => `
          <article class="kpi-card">
            <div class="kpi-label"><span>${label}</span><span>operação</span></div>
            <div class="kpi-value">${value}</div>
            <div class="kpi-trend">base em análise</div>
          </article>
        `).join('')}
      </div>

      <div style="margin-top: 24px;">
        ${renderOperationTable(operation, records)}
      </div>
    </section>
  `;
}

function renderInboundPage(searchTerm = '') {
  return renderOperationPage('inbound', 'Inbound', searchTerm);
}

function renderOutboundPage(searchTerm = '') {
  return renderOperationPage('outbound', 'Outbound', searchTerm);
}

function renderInventoryPage(searchTerm = '') {
  return renderOperationPage('inventory', 'Inventário', searchTerm);
}

function renderRecordsPage() {
  const recordsByOperation = appStore.getState().recordsByOperation;
  const operationGroups = [
    ['inbound', 'Inbound'],
    ['outbound', 'Outbound'],
    ['inventory', 'Inventário']
  ];
  const allRecords = operationGroups.flatMap(([operation]) => recordsByOperation[operation] || []);
  const tables = operationGroups
    .map(([operation, label]) => {
      const records = recordsByOperation[operation] || [];
      if (!records.length) return '';
      return `
        <section class="chart-panel records-operation">
          <div class="records-operation-heading">
            <h3>${label}</h3>
            <span class="status-badge">${records.length} ${records.length === 1 ? 'registro' : 'registros'}</span>
          </div>
          ${renderOperationTable(operation, records)}
        </section>
      `;
    })
    .join('');

  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Base de dados</p>
          <h2>Base de Registros</h2>
        </div>
        <span class="status-badge ${allRecords.length ? 'success' : 'warning'}">${allRecords.length} registros</span>
      </div>
      ${allRecords.length ? `<div class="records-groups">${tables}</div>` : `
        <div class="empty-state">
          <div>
            <h3>Registros detalhados</h3>
            <p>Os registros detalhados entram em exibição paginada após a importação e validação.</p>
          </div>
        </div>
      `}
    </section>
  `;
}

function renderGenericPage(route) {
  const title = routeMap[route] || 'Página';
  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Módulo</p>
          <h2>${title}</h2>
        </div>
      </div>
      <div class="empty-state">
        <div>
          <h3>Em desenvolvimento</h3>
          <p>Este módulo está em construção e será entregue nas fases seguintes da plataforma.</p>
        </div>
      </div>
    </section>
  `;
}

function renderPage() {
  const { route, query } = resolveRoute(window.location.hash || '#/overview');
  const pageContent = {
    '/overview': renderOverviewPage,
    '/indicators': renderIndicatorsPage,
    '/inbound': () => renderInboundPage(query.get('q') || ''),
    '/outbound': () => renderOutboundPage(query.get('q') || ''),
    '/inventory': () => renderInventoryPage(query.get('q') || ''),
    '/productivity': renderProductivityPage,
    '/turnos': renderTurnosPage,
    '/history': renderHistoryPage,
    '/imports': renderImportWizard,
    '/import-history': renderImportHistoryPage,
    '/records': renderRecordsPage,
    '/settings': renderSettingsPage,
    '/users': renderUsersPage
  };

  const renderFn = pageContent[route] || (() => renderGenericPage(route));
  app.innerHTML = renderFn();
  enhanceEmptyStates(app);
  initializeKpiCards();
  initializeDataModeBadge();

  if (route === '/imports') {
    bindImportWizard();
  }

  navButtons.forEach((button) => {
    const isActive = button.dataset.route === `#${route}`;
    button.classList.toggle('active', isActive);
  });

  const filterState = readFilterStateFromHash(window.location.hash);
  applyFilterStateToControls(filterState);

  const routeTitle = routeMap[route] || 'Visão Geral';
  document.title = `${routeTitle} | DHL Operations Hub`;
  return { route, query };
}

function openCommandPalette() {
  commandPaletteReturnFocus = document.activeElement instanceof HTMLElement
    && document.activeElement !== document.body
    ? document.activeElement
    : globalSearch;
  commandPalette.classList.remove('hidden');
  commandInput.setAttribute('aria-expanded', 'true');
  commandInput.value = '';
  commandInput.focus();
  renderCommandList('');
}

function closeCommandPalette() {
  commandPalette.classList.add('hidden');
  commandInput.setAttribute('aria-expanded', 'false');
  commandInput.removeAttribute('aria-activedescendant');
  if (commandPaletteReturnFocus?.isConnected) {
    commandPaletteReturnFocus.focus();
  }
}

function renderCommandList(term) {
  const normalizedTerm = normalizeSearchText(term);
  const items = Object.entries(routeMap)
    .filter(([key, label]) => normalizeSearchText(`${label} ${key}`).includes(normalizedTerm))
    .map(([key, label], index) => `
      <li class="command-item" id="command-option-${index}" data-route="${key}" role="option" aria-selected="false" tabindex="-1">
        <span>${label}</span>
        <span class="search-hit">${key.replace('/', '')}</span>
      </li>
    `)
    .join('');

  commandList.innerHTML = items || '<li class="command-item"><span>Nenhum resultado</span></li>';

  activeCommandIndex = -1;
  commandInput.removeAttribute('aria-activedescendant');
  commandList.querySelectorAll('.command-item').forEach((item) => {
    item.addEventListener('click', () => {
      if (item.dataset.route) {
        window.location.hash = item.dataset.route;
        closeCommandPalette();
      }
    });
  });
}

function setActiveCommand(index) {
  const items = [...commandList.querySelectorAll('[data-route]')];
  if (!items.length) {
    activeCommandIndex = -1;
    return;
  }

  activeCommandIndex = (index + items.length) % items.length;
  items.forEach((item, itemIndex) => {
    item.classList.toggle('active', itemIndex === activeCommandIndex);
    item.setAttribute('aria-selected', String(itemIndex === activeCommandIndex));
  });
  const activeItem = items[activeCommandIndex];
  commandInput.setAttribute('aria-activedescendant', activeItem.id);
  activeItem.scrollIntoView({ block: 'nearest' });
}

function closeGlobalSearchResults() {
  globalSearchResults.classList.add('hidden');
  globalSearch.setAttribute('aria-expanded', 'false');
  globalSearch.removeAttribute('aria-activedescendant');
  activeSearchIndex = -1;
}

function selectGlobalSearchResult(result, term) {
  const route = `/${result.operation}`;
  const query = new URLSearchParams({ q: term.trim() });
  closeGlobalSearchResults();
  globalSearch.value = '';
  window.location.hash = buildHashWithQuery(route, query);
}

function renderGlobalSearchResults(term) {
  const normalizedTerm = term.trim();
  globalSearchResults.replaceChildren();
  activeSearchIndex = -1;

  if (!normalizedTerm) {
    closeGlobalSearchResults();
    return;
  }

  const results = searchRecords(appStore.getState().recordsByOperation, normalizedTerm);
  if (!results.length) {
    const emptyMessage = document.createElement('div');
    emptyMessage.className = 'search-empty';
    emptyMessage.setAttribute('role', 'status');
    emptyMessage.textContent = 'Nenhum registro encontrado';
    globalSearchResults.append(emptyMessage);
  } else {
    const operationLabels = {
      inbound: 'Inbound',
      outbound: 'Outbound',
      inventory: 'Inventário'
    };

    results.forEach((result, index) => {
      const option = document.createElement('button');
      option.type = 'button';
      option.className = 'search-result';
      option.id = `global-search-result-${index}`;
      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', 'false');

      const title = document.createElement('span');
      title.className = 'search-result-title';
      title.textContent = result.record.dt || result.record.sku || result.record.veiculo || result.record.endereco || 'Registro operacional';

      const meta = document.createElement('span');
      meta.className = 'search-result-meta';
      meta.textContent = [
        operationLabels[result.operation] || result.operation,
        result.record.dataOperacional || result.record.data,
        result.record.turno
      ].filter(Boolean).join(' · ');

      option.append(title, meta);
      option.addEventListener('click', () => selectGlobalSearchResult(result, normalizedTerm));
      globalSearchResults.append(option);
    });
  }

  globalSearchResults.classList.remove('hidden');
  globalSearch.setAttribute('aria-expanded', 'true');
}

function setActiveSearchResult(index) {
  const options = [...globalSearchResults.querySelectorAll('[role="option"]')];
  if (!options.length) {
    activeSearchIndex = -1;
    return;
  }

  activeSearchIndex = (index + options.length) % options.length;
  options.forEach((option, optionIndex) => {
    option.setAttribute('aria-selected', String(optionIndex === activeSearchIndex));
  });
  const activeOption = options[activeSearchIndex];
  globalSearch.setAttribute('aria-activedescendant', activeOption.id);
  activeOption.scrollIntoView({ block: 'nearest' });
}

function bindNavigation() {
  if (currentUser.role !== 'admin') {
    navButtons.forEach((button) => {
      if (button.dataset.route === '#/users') {
        button.style.display = 'none';
      }
    });
  }

  navButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const { route } = button.dataset;
      window.location.hash = route;
      renderPage();
    });
  });

  document.querySelectorAll('[data-filter-key]').forEach((control) => {
    control.addEventListener('change', (event) => {
      const target = event.target;
      const state = { [target.dataset.filterKey]: target.value };
      const hash = writeFilterStateToHash(state);
      window.location.hash = hash.replace(/^#/, '');
      renderPage();
    });
  });

  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      openCommandPalette();
      return;
    }

    if (event.key === 'Escape' && !commandPalette.classList.contains('hidden')) {
      closeCommandPalette();
      return;
    }

    if (commandPalette.classList.contains('hidden')) return;

    if (event.key === 'Tab') {
      const focusableItems = [...commandPalette.querySelectorAll('button:not([disabled]), input:not([disabled])')];
      if (!focusableItems.length) {
        event.preventDefault();
        commandInput.focus();
        return;
      }

      const firstItem = focusableItems[0];
      const lastItem = focusableItems[focusableItems.length - 1];
      if (!focusableItems.includes(document.activeElement)) {
        event.preventDefault();
        commandInput.focus();
      } else if (event.shiftKey && document.activeElement === firstItem) {
        event.preventDefault();
        lastItem.focus();
      } else if (!event.shiftKey && document.activeElement === lastItem) {
        event.preventDefault();
        firstItem.focus();
      }
      return;
    }

    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const direction = event.key === 'ArrowDown' ? 1 : -1;
      const nextIndex = activeCommandIndex < 0
        ? (direction > 0 ? 0 : commandList.querySelectorAll('[data-route]').length - 1)
        : activeCommandIndex + direction;
      setActiveCommand(nextIndex);
    } else if (event.key === 'Enter') {
      const activeItem = commandList.querySelectorAll('[data-route]')[activeCommandIndex];
      if (activeItem) activeItem.click();
    }
  });

  commandInput.addEventListener('input', (event) => {
    renderCommandList(event.target.value);
  });

  document.querySelector('[data-close-command]').addEventListener('click', closeCommandPalette);
  commandPalette.addEventListener('click', (event) => {
    if (event.target === commandPalette) closeCommandPalette();
  });
  globalSearch.addEventListener('input', (event) => {
    renderGlobalSearchResults(event.target.value);
  });
  globalSearch.addEventListener('keydown', (event) => {
    const options = globalSearchResults.querySelectorAll('[role="option"]');

    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      if (!options.length) return;
      event.preventDefault();
      const direction = event.key === 'ArrowDown' ? 1 : -1;
      const nextIndex = activeSearchIndex < 0
        ? (direction > 0 ? 0 : options.length - 1)
        : activeSearchIndex + direction;
      setActiveSearchResult(nextIndex);
    } else if (event.key === 'Enter' && !globalSearchResults.classList.contains('hidden')) {
      event.preventDefault();
      const selectedOption = options[activeSearchIndex < 0 ? 0 : activeSearchIndex];
      selectedOption?.click();
    } else if (event.key === 'Escape') {
      closeGlobalSearchResults();
    }
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.search-wrap')) closeGlobalSearchResults();
  });

  toggleSidebar.addEventListener('click', () => {
    document.body.classList.toggle('sidebar-collapsed');
  });

  sidebarOverlay.addEventListener('click', () => {
    document.body.classList.toggle('sidebar-collapsed');
  });

  tvModeButton.addEventListener('click', () => {
    setTvMode(!document.body.classList.contains('tv-mode'));
  });

  window.addEventListener('hashchange', renderPage);
}

function init() {
  if (!window.location.hash) {
    window.location.hash = '#/overview';
  }

  bindNavigation();
  renderPage();
  initializeLucideIcons();
  console.info('Usuário atual:', currentUser.name, '| Papel:', currentUser.role);
  console.info('Acesso Firebase:', firebaseStatus.mode);
  console.info('Turno', getTurnoByHour(new Date(2026, 0, 14, 21, 45)));
}

init();
