self.onmessage = (event) => {
  const { fileText, fileName } = event.data || {};

  if (!fileText) {
    self.postMessage({ ok: false, error: 'Arquivo vazio' });
    return;
  }

  const rows = fileName.toLowerCase().endsWith('.csv') ? parseCsv(fileText) : [{ fileName, fileText }];
  self.postMessage({ ok: true, rows });
};

function parseCsv(text) {
  const normalized = text.replace(/\r\n/g, '\n');
  const lines = normalized.split('\n').filter((line) => line.trim() !== '');
  const result = lines.slice(0, 10).map((line) => line.split(','));
  return result;
}
