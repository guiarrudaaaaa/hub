import { runImportJob } from './services/import.js';
import { appStore } from './store.js';
import { enhanceEmptyStates, showSkeleton, showToast } from './components/feedback.js';

export function renderImportWizard() {
  return `
    <section class="page-card">
      <div class="page-header">
        <div>
          <p class="eyebrow">Gestão de dados</p>
          <h2>Importar Dados</h2>
        </div>
        <span class="status-badge warning">Pipeline em validação</span>
      </div>

      <div class="import-wizard" aria-label="Wizard de importação">
        <span class="wizard-step active">1. Operação</span>
        <span class="wizard-step">2. Arquivo</span>
        <span class="wizard-step">3. Mapeamento</span>
        <span class="wizard-step">4. Validação</span>
        <span class="wizard-step">5. Confirmação</span>
      </div>

      <div class="page-grid" style="margin-top: 24px;">
        <div class="chart-panel">
          <h3>Operação e arquivo</h3>
          <label for="import-operation" class="field-label">Operação</label>
          <select id="import-operation" class="field-control">
            <option value="inbound">Inbound</option>
            <option value="outbound">Outbound</option>
            <option value="inventory">Inventário</option>
          </select>

          <label for="import-file-input" class="field-label" style="margin-top: 16px; display: block;">Arquivo (.csv ou .xlsx)</label>
          <input id="import-file-input" type="file" accept=".csv,.xlsx,.xls" class="field-control" />
        </div>

        <div class="chart-panel">
          <h3>Resumo da importação</h3>
          <div id="import-summary" class="page-subtitle">
            <p>Sem arquivo carregado. Antes da importação, o sistema mantém estados vazios e seguros.</p>
          </div>
        </div>
      </div>

      <div class="page-card" style="margin-top: 24px;">
        <h3>Prévia das primeiras linhas</h3>
        <div id="import-preview" class="empty-state">
          <div>
            <h3>Estado vazio</h3>
            <p>As primeiras linhas aparecerão aqui após a leitura do arquivo.</p>
          </div>
        </div>
      </div>
    </section>
  `;
}

export async function bindImportWizard() {
  const fileInput = document.getElementById('import-file-input');
  const operationSelect = document.getElementById('import-operation');
  const summaryNode = document.getElementById('import-summary');
  const previewNode = document.getElementById('import-preview');

  if (!fileInput || !operationSelect || !summaryNode || !previewNode) {
    return;
  }

  fileInput.addEventListener('change', async (event) => {
    const file = event.target.files?.[0];
    if (!file) {
      summaryNode.innerHTML = '<p>Sem arquivo selecionado.</p>';
      return;
    }

    fileInput.disabled = true;
    operationSelect.disabled = true;
    previewNode.className = 'import-preview-skeleton';
    showSkeleton(summaryNode, 'Processando arquivo', 3);
    showSkeleton(previewNode, 'Lendo prévia do arquivo', 5);

    try {
      const result = await runImportJob(file, operationSelect.value);
      appStore.appendImportJob(result);

      summaryNode.innerHTML = `
        <p><strong>Operação:</strong> ${result.operation}</p>
        <p><strong>Registros válidos:</strong> ${result.validRows}</p>
        <p><strong>Inválidos:</strong> ${result.invalidRows}</p>
        <p><strong>Duplicados:</strong> ${result.duplicates}</p>
        <p><strong>Atualizações:</strong> ${result.updates}</p>
        <p><strong>Status:</strong> ${result.status}</p>
      `;
      showToast(
        result.validRows
          ? `Importação concluída: ${result.validRows} registros válidos e ${result.invalidRows} inválidos.`
          : 'Arquivo processado, mas nenhum registro foi válido.',
        result.validRows ? 'success' : 'error'
      );

      const rows = result.preview || [];
      if (!rows.length) {
        previewNode.className = 'empty-state';
        previewNode.innerHTML = '<div><h3>Sem prévia</h3><p>Não há linhas suficientes para exibir.</p></div>';
        enhanceEmptyStates(previewNode);
        return;
      }

      const headers = rows[0];
      const previewRows = rows.slice(1, 5);
      previewNode.className = 'import-preview-table';
      previewNode.innerHTML = `
        <table>
          <thead>
            <tr>${headers.map((header) => `<th>${header}</th>`).join('')}</tr>
          </thead>
          <tbody>
            ${previewRows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}
          </tbody>
        </table>
      `;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Erro inesperado ao processar o arquivo.';
      summaryNode.textContent = `Erro na importação: ${message}`;
      previewNode.className = 'empty-state';
      previewNode.innerHTML = '<div><h3>Erro</h3><p>Não foi possível processar o arquivo carregado.</p></div>';
      enhanceEmptyStates(previewNode);
      showToast(message, 'error');
    } finally {
      fileInput.disabled = false;
      operationSelect.disabled = false;
      summaryNode.removeAttribute('aria-busy');
      previewNode.removeAttribute('aria-busy');
    }
  });
}
