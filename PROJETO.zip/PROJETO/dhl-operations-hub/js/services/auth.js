export async function signInWithEmailPassword(email, password) {
  if (!email || !password) {
    throw new Error('Credenciais inválidas');
  }

  return {
    uid: 'local-dev-admin',
    email,
    role: 'admin',
    name: 'Administrador local'
  };
}

export function getCurrentUser() {
  return {
    uid: 'local-dev-admin',
    email: 'admin@dhl.local',
    role: 'admin',
    name: 'Administrador local'
  };
}

export function signOut() {
  return true;
}
