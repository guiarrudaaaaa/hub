import { parseCsvText, suggestColumnMapping, validateImportedRow } from '../utils/import-utils.js';
import { buildDedupKey } from '../utils/hash.js';

export function createParseWorker() {
  if (typeof Worker === 'undefined') {
    return null;
  }

  return new Worker(new URL('../workers/parse-worker.js', import.meta.url), { type: 'module' });
}

export async function loadSheetJs() {
  if (typeof window === 'undefined' || window.XLSX) {
    return !!(typeof window !== 'undefined' && window.XLSX);
  }

  await new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.sheetjs.com/xlsx-0.19.3/package/dist/xlsx.full.min.js';
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error('Falha ao carregar SheetJS')); 
    document.head.appendChild(script);
  });

  return !!window.XLSX;
}

export async function parseFile(file) {
  if (!file) {
    throw new Error('Selecione um arquivo para importação.');
  }

  if (file.name.toLowerCase().endsWith('.csv')) {
    const fileText = await file.text();
    const rows = parseCsvText(fileText);

    if (!rows.length) {
      throw new Error('Arquivo sem conteúdo válido para leitura.');
    }

    return {
      fileName: file.name,
      rows,
      headers: rows[0],
      dataRows: rows.slice(1)
    };
  }

  if (file.name.toLowerCase().endsWith('.xlsx') || file.name.toLowerCase().endsWith('.xls')) {
    await loadSheetJs();
    const arrayBuffer = await file.arrayBuffer();
    const workbook = window.XLSX.read(arrayBuffer, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = window.XLSX.utils.sheet_to_json(firstSheet, { header: 1, raw: false });

    if (!rows.length) {
      throw new Error('Arquivo Excel sem conteúdo válido para leitura.');
    }

    return {
      fileName: file.name,
      rows,
      headers: rows[0],
      dataRows: rows.slice(1)
    };
  }

  throw new Error('Formato de arquivo não suportado. Use CSV ou XLSX.');
}

export async function runImportJob(file, operation = 'inbound') {
  const parsed = await parseFile(file);
  const logs = parsed.dataRows.map((row, index) => {
    const object = Object.fromEntries(parsed.headers.map((header, colIndex) => [header, row[colIndex] ?? '']));
    const mapping = suggestColumnMapping(parsed.headers, operation);
    const normalized = Object.fromEntries(
      Object.entries(mapping).map(([header, field]) => [field, object[header]])
    );

    const validation = validateImportedRow(normalized, operation);
    return {
      rowIndex: index + 2,
      values: row,
      normalized,
      validation,
      dedupKey: null
    };
  });

  const validRows = [];
  const invalidRows = [];
  let duplicates = 0;
  let updates = 0;

  for (const row of logs) {
    if (!row.validation.valid) {
      invalidRows.push(row);
      continue;
    }

    const keyParts = [
      row.normalized.dataOperacional,
      row.normalized.dt,
      row.normalized.turno,
      row.normalized.veiculo || row.normalized.sku || row.normalized.endereco,
      row.normalized.checkIn || row.normalized.inicioOperacao || row.normalized.qtdSistemica
    ].filter(Boolean);

    row.dedupKey = await buildDedupKey(operation, keyParts);
    validRows.push(row);
  }

  const records = validRows.map((row) => ({
    ...row.normalized,
    dedupKey: row.dedupKey,
    importId: row.dedupKey,
    operation
  }));

  return {
    operation,
    status: validRows.length ? 'validado' : 'sem_registros_validos',
    validRows: validRows.length,
    invalidRows: invalidRows.length,
    duplicates,
    updates,
    preview: [parsed.headers, ...parsed.dataRows.slice(0, 5)],
    records
  };
}

export async function importRecords() {
  return {
    status: 'em_andamento',
    imported: 0,
    skipped: 0
  };
}
