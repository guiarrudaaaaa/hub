export async function listCollection(collectionName) {
  return {
    collection: collectionName,
    data: [],
    source: 'local-development'
  };
}
