export function logAuditEntry(action, entity, details = {}) {
  return {
    action,
    entity,
    details,
    createdAt: new Date().toISOString()
  };
}
