export const routeMap = {
  '/overview': 'Visão Geral',
  '/indicators': 'Central de Indicadores',
  '/inbound': 'Inbound',
  '/outbound': 'Outbound',
  '/inventory': 'Inventário',
  '/productivity': 'Produtividade',
  '/turnos': 'Performance por Turno',
  '/history': 'Análise Histórica',
  '/imports': 'Importar Dados',
  '/import-history': 'Histórico de Importações',
  '/records': 'Base de Registros',
  '/settings': 'Configurações',
  '/users': 'Administração de Usuários'
};

export function resolveRoute(hash = window.location.hash) {
  const hashPart = hash.startsWith('#') ? hash.slice(1) : hash;
  const [routePath] = hashPart.split('?');
  const normalized = routePath.startsWith('/') ? routePath : '/overview';
  const route = normalized in routeMap ? normalized : '/overview';
  return {
    route,
    query: new URLSearchParams(hashPart.includes('?') ? hashPart.slice(hashPart.indexOf('?') + 1) : '')
  };
}

export function buildHashWithQuery(route, query = new URLSearchParams()) {
  const search = query.toString();
  return search ? `#${route}?${search}` : `#${route}`;
}
