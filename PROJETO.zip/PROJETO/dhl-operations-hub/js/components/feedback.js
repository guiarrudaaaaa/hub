const svgNamespace = 'http://www.w3.org/2000/svg';

function createEmptyStateIllustration() {
  const svg = document.createElementNS(svgNamespace, 'svg');
  svg.classList.add('empty-state-illustration');
  svg.setAttribute('viewBox', '0 0 64 64');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');

  [
    'm12 20 20-10 20 10-20 10z',
    'm12 20v23l20 11 20-11V20',
    'm32 30v24',
    'm22 15 20 10',
    'm21 41 8-7 7 5 11-12',
    'm42 27h5v5'
  ].forEach((pathData) => {
    const path = document.createElementNS(svgNamespace, 'path');
    path.setAttribute('d', pathData);
    svg.append(path);
  });

  return svg;
}

export function enhanceEmptyStates(root = document) {
  const emptyStates = [];
  if (root.matches?.('.empty-state')) emptyStates.push(root);
  emptyStates.push(...root.querySelectorAll('.empty-state'));

  emptyStates.forEach((state) => {
    const content = state.querySelector(':scope > div') || state;
    if (!content.querySelector('.empty-state-illustration')) {
      content.prepend(createEmptyStateIllustration());
    }

    if (content.querySelector('.empty-state-action')) return;

    const action = document.createElement('button');
    action.type = 'button';
    action.className = 'primary-button empty-state-action';
    action.textContent = 'Importar arquivo';
    action.addEventListener('click', () => {
      if (window.location.hash.startsWith('#/imports')) {
        const fileInput = document.getElementById('import-file-input');
        if (fileInput) {
          fileInput.click();
          return;
        }
        console.error('O campo de arquivo não está disponível na tela de importação.');
        return;
      }

      window.location.hash = '#/imports';
    });
    content.append(action);
  });
}

export function showSkeleton(container, label, blockCount = 3) {
  const stack = document.createElement('div');
  stack.className = 'skeleton-stack';
  stack.setAttribute('role', 'status');
  stack.setAttribute('aria-label', label);
  container.setAttribute('aria-busy', 'true');

  for (let index = 0; index < blockCount; index += 1) {
    const block = document.createElement('span');
    block.className = 'skeleton-block';
    block.setAttribute('aria-hidden', 'true');
    stack.append(block);
  }

  container.replaceChildren(stack);
}

export function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) {
    console.error('O contêiner de notificações não está disponível.');
    return;
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  toast.textContent = message;
  container.append(toast);
  window.setTimeout(() => toast.remove(), 5000);
}
