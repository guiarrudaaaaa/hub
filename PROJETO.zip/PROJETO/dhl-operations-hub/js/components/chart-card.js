export function renderChartCard(title, subtitle, body, footer = '') {
  return `
    <article class="chart-panel">
      <div class="page-header">
        <div>
          <p class="eyebrow">Análise</p>
          <h3>${title}</h3>
        </div>
      </div>
      <div class="page-subtitle">
        <p>${subtitle}</p>
      </div>
      ${body || '<div class="empty-state"><div><h3>Sem dados</h3><p>Não há dados para este gráfico.</p></div></div>'}
      ${footer ? `<div class="page-subtitle" style="margin-top: 12px;">${footer}</div>` : ''}
    </article>
  `;
}
