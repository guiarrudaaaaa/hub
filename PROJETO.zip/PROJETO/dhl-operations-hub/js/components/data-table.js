export function renderTable(headers = [], rows = []) {
  if (!headers.length) {
    return '<div class="empty-state"><div><h3>Sem tabela</h3><p>Não há colunas para renderizar.</p></div></div>';
  }

  return `
    <div class="import-preview-table">
      <table>
        <thead>
          <tr>${headers.map((header) => `<th>${header}</th>`).join('')}</tr>
        </thead>
        <tbody>
          ${rows.map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}
