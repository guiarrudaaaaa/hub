export function normalizeSearchText(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

export function matchesRecordSearch(record, term) {
  const normalizedTerm = normalizeSearchText(term);
  if (!normalizedTerm) return true;

  return Object.entries(record).some(([key, value]) => {
    if (key === 'dedupKey' || key === 'importId') return false;
    if (typeof value !== 'string' && typeof value !== 'number') return false;
    return normalizeSearchText(value).includes(normalizedTerm);
  });
}

export function filterRecordsBySearch(records, term) {
  if (!normalizeSearchText(term)) return records;
  return records.filter((record) => matchesRecordSearch(record, term));
}

export function searchRecords(recordsByOperation, term, limit = 6) {
  if (!normalizeSearchText(term) || limit <= 0) return [];

  return Object.entries(recordsByOperation)
    .flatMap(([operation, records]) =>
      records
        .filter((record) => matchesRecordSearch(record, term))
        .map((record) => ({ operation, record }))
    )
    .slice(0, limit);
}
