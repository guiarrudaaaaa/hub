export function parseNumber(value) {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }

  let normalized = String(value ?? '').trim().replace(/\s/g, '');
  const hasComma = normalized.includes(',');
  const hasPeriod = normalized.includes('.');

  if (hasComma && hasPeriod) {
    if (normalized.lastIndexOf(',') > normalized.lastIndexOf('.')) {
      normalized = normalized.replace(/\./g, '').replace(/,/g, '.');
    } else {
      normalized = normalized.replace(/,/g, '');
    }
  } else if (hasComma) {
    normalized = normalized.replace(/,/g, '.');
  } else if (/^-?\d{1,3}(?:\.\d{3})+$/.test(normalized)) {
    normalized = normalized.replace(/\./g, '');
  }

  const numeric = Number(normalized);
  return Number.isFinite(numeric) ? numeric : 0;
}

export function summarizeOperation(records = [], operation = 'inbound') {
  if (!Array.isArray(records) || records.length === 0) {
    return null;
  }

  const totalRows = records.length;
  const totalTon = records.reduce((sum, row) => sum + parseNumber(row.toneladas ?? row.qtdSistemica ?? 0), 0);
  const totalPallets = records.reduce((sum, row) => sum + parseNumber(row.pallets ?? 0), 0);
  let totalSla = 0;
  let withinSla = 0;

  records.forEach((row) => {
    const slaStatus = String(row.slaStatus ?? row.status ?? '').toLowerCase();
    if (slaStatus.includes('within') || slaStatus.includes('dentro') || slaStatus.includes('ok') || slaStatus === 'dentro_do_sla') {
      withinSla += 1;
    }
    totalSla += 1;
  });

  const slaRate = totalSla ? (withinSla / totalSla) * 100 : 0;
  const accuracy = operation === 'inventory'
    ? records.reduce((sum, row) => sum + parseNumber(row.acuracia ?? 0), 0) / totalRows
    : null;

  return {
    totalRows,
    totalTon,
    totalPallets,
    slaRate,
    accuracy,
    operation
  };
}

export function summarizeByOperation(recordsByOperation = {}) {
  const operations = ['inbound', 'outbound', 'inventory'];
  const entries = operations.map((operation) => {
    const records = Array.isArray(recordsByOperation[operation]) ? recordsByOperation[operation] : [];
    const summary = summarizeOperation(records, operation);

    return {
      operation,
      totalRows: summary ? summary.totalRows : 0,
      totalTon: summary ? summary.totalTon : 0,
      slaRate: summary ? summary.slaRate : 0,
      accuracy: summary && summary.accuracy !== null ? summary.accuracy : 0
    };
  });

  const totalRows = entries.reduce((sum, entry) => sum + entry.totalRows, 0);
  const totalTon = entries.reduce((sum, entry) => sum + entry.totalTon, 0);
  const bestOperation = entries
    .filter((entry) => entry.totalRows > 0)
    .sort((a, b) => b.totalTon - a.totalTon)[0] ?? null;

  return {
    entries,
    totalRows,
    totalTon,
    bestOperation
  };
}

export function summarizeByShift(records = []) {
  const shifts = ['T1', 'T2', 'T3'].map((turno) => ({
    turno,
    totalRows: 0,
    totalTon: 0
  }));

  records.forEach((row) => {
    const turnoValue = String(row.turno ?? row.turnoOperacional ?? row.turnoOp ?? '').toUpperCase();
    const matchedShift = shifts.find((entry) => entry.turno === turnoValue) || shifts[0];

    matchedShift.totalRows += 1;
    matchedShift.totalTon += parseNumber(row.toneladas ?? row.qtdSistemica ?? 0);
  });

  const peakShift = shifts
    .filter((entry) => entry.totalRows > 0)
    .sort((a, b) => b.totalRows - a.totalRows)[0] ?? null;

  return {
    shifts,
    peakShift,
    totalRows: shifts.reduce((sum, entry) => sum + entry.totalRows, 0)
  };
}

export function buildImportHistorySummary(jobs = []) {
  const totals = jobs.reduce((summary, job) => {
    summary.totalJobs += 1;
    summary.validRows += Number(job.validRows || 0);
    summary.invalidRows += Number(job.invalidRows || 0);
    summary.duplicates += Number(job.duplicates || 0);
    summary.updates += Number(job.updates || 0);
    return summary;
  }, {
    totalJobs: 0,
    validRows: 0,
    invalidRows: 0,
    duplicates: 0,
    updates: 0
  });

  const totalProcessed = totals.validRows + totals.invalidRows;
  const acceptanceRate = totalProcessed ? (totals.validRows / totalProcessed) * 100 : 0;

  return {
    ...totals,
    acceptanceRate,
    latestStatus: jobs[0]?.status || 'sem_importacao'
  };
}
