export function parseNumberBR(value) {
  if (value === null || value === undefined || value === '') return null;
  const normalized = String(value).trim().replace('.', '').replace(',', '.');
  const numericValue = Number(normalized);
  return Number.isFinite(numericValue) ? numericValue : null;
}

export function isRequired(value) {
  if (typeof value === 'string') {
    return value.trim().length > 0;
  }
  return value !== null && value !== undefined && value !== '';
}

export function validateDateBR(value) {
  return /^\d{2}\/\d{2}\/\d{4}$/.test(String(value || ''));
}

export function normalizeDedupKey(parts) {
  return parts
    .map((part) => String(part).trim())
    .filter(Boolean)
    .join('|')
    .toLowerCase();
}
