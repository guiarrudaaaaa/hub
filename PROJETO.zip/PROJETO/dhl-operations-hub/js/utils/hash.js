export async function sha256Hex(value) {
  const normalized = typeof value === 'string' ? value : JSON.stringify(value ?? '');

  if (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle) {
    const buffer = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(normalized));
    return Array.from(new Uint8Array(buffer))
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
  }

  const nodeCrypto = await import('node:crypto');
  return nodeCrypto.createHash('sha256').update(normalized, 'utf8').digest('hex');
}

export async function buildDedupKey(moduleName, values = []) {
  const normalized = [moduleName, ...values]
    .map((value) => String(value ?? '').trim().replace(/\s+/g, ' ').toLowerCase())
    .filter(Boolean)
    .join('|');

  return sha256Hex(normalized);
}
