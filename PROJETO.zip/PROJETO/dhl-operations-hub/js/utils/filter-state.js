export const FILTER_KEYS = ['year', 'month', 'range', 'operation', 'turno', 'status'];

export function readFilterStateFromHash(hash = window.location.hash) {
  const params = new URLSearchParams(hash.includes('?') ? hash.slice(hash.indexOf('?') + 1) : '');
  const state = {};

  for (const key of FILTER_KEYS) {
    const value = params.get(key);
    if (value) state[key] = value;
  }

  return state;
}

export function applyFilterStateToControls(state = {}) {
  const controls = [...document.querySelectorAll('[data-filter-key]')];
  for (const control of controls) {
    const key = control.dataset.filterKey;
    const value = state[key] || control.dataset.defaultValue || control.value;
    if (value) {
      control.value = value;
    }
  }
}

export function writeFilterStateToHash(nextState = {}) {
  const hash = window.location.hash || '#/overview';
  const route = hash.split('?')[0];
  const currentParams = new URLSearchParams(hash.includes('?') ? hash.slice(hash.indexOf('?') + 1) : '');
  const params = new URLSearchParams();
  const current = readFilterStateFromHash(window.location.hash);
  const merged = { ...current, ...nextState };

  const searchTerm = currentParams.get('q');
  if (searchTerm) params.set('q', searchTerm);

  for (const [key, value] of Object.entries(merged)) {
    if (value && value !== 'all') params.set(key, value);
  }

  const query = params.toString();
  const target = query ? `${route}?${query}` : route;
  window.history.replaceState({}, '', `#${target.replace(/^#/, '')}`);
  return target;
}
