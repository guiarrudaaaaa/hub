export function parseCsvText(csvText) {
  if (!csvText || !csvText.trim()) {
    return [];
  }

  const rows = [];
  let row = [];
  let value = '';
  let inQuotes = false;

  for (let i = 0; i < csvText.length; i += 1) {
    const current = csvText[i];
    const next = csvText[i + 1];

    if (current === '"') {
      if (inQuotes && next === '"') {
        value += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (current === ',' && !inQuotes) {
      row.push(value);
      value = '';
      continue;
    }

    if ((current === '\n' || current === '\r') && !inQuotes) {
      if (current === '\r' && next === '\n') {
        i += 1;
      }
      row.push(value);
      if (row.some((cell) => cell !== '')) {
        rows.push(row);
      }
      row = [];
      value = '';
      continue;
    }

    value += current;
  }

  if (value.length > 0 || row.length > 0) {
    row.push(value);
    if (row.some((cell) => cell !== '')) {
      rows.push(row);
    }
  }

  return rows;
}

export function suggestColumnMapping(headers = [], operation = 'inbound') {
  const aliases = {
    inbound: {
      dataOperacional: ['data', 'data operacional', 'dt_data', 'operational date'],
      dt: ['dt', 'documento de transporte', 'd.t.', 'document transport'],
      turno: ['turno', 'shift'],
      veiculo: ['veiculo', 'vehicle', 'placa', 'plate'],
      checkIn: ['checkin', 'check-in', 'check in', 'entrada'],
      tempoProcesso: ['tempo processo', 'tempo de processo', 'process time'],
      toneladas: ['toneladas', 'tons', 'weight_tons'],
      pallets: ['pallets', 'pallet']
    },
    outbound: {
      dataOperacional: ['data', 'data operacional', 'operational date'],
      dt: ['dt', 'documento de transporte', 'd.t.'],
      turno: ['turno', 'shift'],
      veiculo: ['veiculo', 'vehicle', 'placa', 'plate'],
      inicioOperacao: ['inicio operacao', 'inicio', 'start time'],
      toneladas: ['toneladas', 'tons', 'weight_tons'],
      volumes: ['volumes', 'qty volumes']
    },
    inventory: {
      sku: ['sku', 'item', 'produto'],
      descricao: ['descricao', 'description', 'produto descricao'],
      endereco: ['endereco', 'location', 'slot'],
      qtdSistemica: ['qtd sistemica', 'qtd sistema', 'system qty'],
      qtdFisica: ['qtd fisica', 'physical qty', 'quantidade fisica'],
      divergencia: ['divergencia', 'variance', 'diferença']
    }
  };

  const mapping = {};
  headers.forEach((header) => {
    const normalized = String(header).trim().toLowerCase();
    let target = null;

    for (const [fieldName, candidates] of Object.entries(aliases[operation] || {})) {
      if (candidates.includes(normalized)) {
        target = fieldName;
        break;
      }
    }

    if (!target) {
      target = normalized.replace(/[^a-z]/g, '');
    }

    mapping[header] = target;
  });

  return mapping;
}

export function validateImportedRow(row = {}, operation = 'inbound') {
  const errors = [];
  const requiredFields = {
    inbound: ['dataOperacional', 'dt', 'turno', 'veiculo'],
    outbound: ['dataOperacional', 'dt', 'turno', 'veiculo'],
    inventory: ['sku', 'endereco', 'qtdSistemica', 'qtdFisica']
  };

  for (const field of requiredFields[operation] || []) {
    if (!row[field] || String(row[field]).trim() === '') {
      errors.push(`Campo obrigatório ausente: ${field}`);
    }
  }

  if (row.toneladas !== undefined && Number(row.toneladas) < 0) {
    errors.push('Toneladas não podem ser negativas');
  }

  if (row.qtdFisica !== undefined && row.qtdSistemica !== undefined) {
    const physical = Number(row.qtdFisica);
    const system = Number(row.qtdSistemica);
    if (Number.isFinite(physical) && Number.isFinite(system) && system === 0) {
      errors.push('Quantidade sistêmica não pode ser zero');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}
