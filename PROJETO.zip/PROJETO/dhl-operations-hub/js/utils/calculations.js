export function toKg(value, unit = 'kg') {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) {
    throw new TypeError('Valor numérico inválido');
  }

  if (unit === 't') return numericValue * 1000;
  if (unit === 'kg') return numericValue;
  throw new Error('Unidade inválida. Use "kg" ou "t".');
}

export function toTon(value, unit = 'kg') {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) {
    throw new TypeError('Valor numérico inválido');
  }

  if (unit === 'kg') return numericValue / 1000;
  if (unit === 't') return numericValue;
  throw new Error('Unidade inválida. Use "kg" ou "t".');
}

export function calculateAccuracy(qtdFisica, qtdSistemica) {
  const physical = Number(qtdFisica);
  const system = Number(qtdSistemica);

  if (!Number.isFinite(physical) || !Number.isFinite(system) || system === 0) {
    return 0;
  }

  return (physical / system) * 100;
}
