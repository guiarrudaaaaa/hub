export function normalizeDateString(value) {
  if (!value || typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;

  const match = trimmed.match(/^\d{2}\/\d{2}\/\d{4}$/);
  if (!match) return null;

  const [day, month, year] = trimmed.split('/').map(Number);
  const date = new Date(year, month - 1, day);
  if (Number.isNaN(date.getTime())) return null;
  if (date.getDate() !== day || date.getMonth() !== month - 1 || date.getFullYear() !== year) {
    return null;
  }

  return date;
}

export function getTurnoByHour(dateValue) {
  const date = dateValue instanceof Date ? dateValue : new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    throw new TypeError('Data inválida');
  }

  const minutes = (date.getHours() * 60) + date.getMinutes();
  if (minutes >= 330 && minutes < 820) return 'T1';
  if (minutes >= 820 && minutes < 1320) return 'T2';
  return 'T3';
}

export function resolveOperationalDate(dateValue) {
  const date = dateValue instanceof Date ? dateValue : new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    throw new TypeError('Data inválida');
  }

  const turno = getTurnoByHour(date);
  if (turno === 'T3') {
    const minutes = date.getHours() * 60 + date.getMinutes();
    if (minutes < 1320) {
      const prior = new Date(date);
      prior.setDate(prior.getDate() - 1);
      return prior;
    }
  }

  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

export function getOperationalDateKey(dateValue) {
  const date = resolveOperationalDate(dateValue);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
