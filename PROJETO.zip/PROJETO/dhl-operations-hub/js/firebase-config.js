export const firebaseConfig = {
  apiKey: 'demo-api-key',
  authDomain: 'dhl-operations-hub.firebaseapp.com',
  projectId: 'dhl-operations-hub',
  storageBucket: 'dhl-operations-hub.appspot.com',
  messagingSenderId: '000000000000',
  appId: '1:000000000000:web:demo'
};

export function initFirebase() {
  return {
    app: null,
    auth: null,
    db: null,
    enabled: false,
    mode: 'development'
  };
}
