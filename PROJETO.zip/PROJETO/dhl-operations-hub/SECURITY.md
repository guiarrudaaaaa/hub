# Segurança e publicação

## Modelo de ameaças

Este projeto usa uma abordagem defensiva com foco em:

- autenticação forte via Firebase Auth;
- controle de acesso por roles no Firestore;
- App Check ativado e obrigatório;
- validação rigorosa em importação e dados de escrita;
- auditoria de ação sensível;
- headers HTTP restritivos em Hosting.

## Controles implementados

- cadastro público desabilitado;
- usuários provisionados manualmente;
- papéis `admin`, `analista` e `visualizador`;
- negação por padrão em `firestore.rules`;
- validação de campos obrigatórios e tipos;
- log imutável em `audit_log`;
- sanitização e tratamento seguro de erros no frontend;
- CSP, HSTS, X-Frame-Options, Referrer-Policy e Permissions-Policy.

## Checklist de publicação

- [ ] Ativar App Check em ambiente de produção
- [ ] Configurar domínio de hosting no Firebase
- [ ] Provisionar primeiro admin manualmente via console
- [ ] Validar regras do Firestore com Emulator Suite
- [ ] Revisar logs de auditoria e acesso
- [ ] Acompanhar orçamento do Firebase Blaze
- [ ] Validar CSP e headers em produção

## Observação

A aplicação foi montada com foco em arquitetura e segurança, mas a activação de credenciais reais de Firebase e a publicação em produção dependem dos valores do ambiente da organização.
