import test from 'node:test';
import assert from 'node:assert/strict';

import { parseCsvText, suggestColumnMapping, validateImportedRow } from '../js/utils/import-utils.js';
import { buildDedupKey } from '../js/utils/hash.js';

test('parseCsvText interpreta linhas com aspas e delimitadores', () => {
  const rows = parseCsvText('data,dt,turno\n15/03/2026,DT-101,T1\n"16/03/2026","DT-102","T2"');
  assert.deepEqual(rows[0], ['data', 'dt', 'turno']);
  assert.deepEqual(rows[1], ['15/03/2026', 'DT-101', 'T1']);
  assert.deepEqual(rows[2], ['16/03/2026', 'DT-102', 'T2']);
});

test('suggestColumnMapping identifica campos por similaridade', () => {
  const mapping = suggestColumnMapping(['Data', 'DT', 'Turno', 'Veículo'], 'inbound');
  assert.equal(mapping['Data'], 'dataOperacional');
  assert.equal(mapping['Turno'], 'turno');
});

test('validateImportedRow rejeita itens obrigatórios vazios', () => {
  const result = validateImportedRow({ dt: 'DT-1', turno: 'T1' }, 'inbound');
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((error) => error.includes('dataOperacional')));
});

test('buildDedupKey retorna identificador determinístico', async () => {
  const keyA = await buildDedupKey('inbound', ['2026-03-15', 'DT-101', 'T1', 'ABC-123', '08:30']);
  const keyB = await buildDedupKey('inbound', ['2026-03-15', 'DT-101', 'T1', 'ABC-123', '08:30']);
  assert.equal(keyA, keyB);
  assert.match(keyA, /^[a-f0-9]{64}$/);
});
