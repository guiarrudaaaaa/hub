import test from 'node:test';
import assert from 'node:assert/strict';

import { filterRecordsBySearch, searchRecords } from '../js/utils/search.js';

const recordsByOperation = {
  inbound: [
    { dt: 'DT-101', turno: 'T1', dedupKey: 'secret-key' },
    { dt: 'DT-202', turno: 'T2' }
  ],
  inventory: [{ sku: 'Café-01', endereco: 'A-10' }]
};

test('searchRecords finds a record by value and returns its operation', () => {
  assert.deepEqual(searchRecords(recordsByOperation, 'dt-101'), [
    { operation: 'inbound', record: recordsByOperation.inbound[0] }
  ]);
});

test('searchRecords ignores internal keys and matches without accents', () => {
  assert.deepEqual(searchRecords(recordsByOperation, 'secret-key'), []);
  assert.deepEqual(searchRecords(recordsByOperation, 'cafe-01'), [
    { operation: 'inventory', record: recordsByOperation.inventory[0] }
  ]);
});

test('filterRecordsBySearch returns all records for an empty query', () => {
  assert.equal(filterRecordsBySearch(recordsByOperation.inbound, '').length, 2);
});
