import test from 'node:test';
import assert from 'node:assert/strict';

import {
  normalizeDateString,
  getTurnoByHour,
  resolveOperationalDate,
  getOperationalDateKey
} from '../js/utils/date-utils.js';

test('normalizeDateString aceita datas no padrão brasileiro', () => {
  const result = normalizeDateString('15/03/2026');
  assert.ok(result instanceof Date);
  assert.equal(result.getFullYear(), 2026);
  assert.equal(result.getMonth(), 2);
  assert.equal(result.getDate(), 15);
});

test('getTurnoByHour classifica corretamente o T3 ao longo da meia-noite', () => {
  assert.equal(getTurnoByHour(new Date(2026, 2, 15, 1, 15)), 'T3');
  assert.equal(getTurnoByHour(new Date(2026, 2, 15, 5, 29)), 'T3');
  assert.equal(getTurnoByHour(new Date(2026, 2, 15, 5, 30)), 'T1');
  assert.equal(getTurnoByHour(new Date(2026, 2, 15, 21, 45)), 'T2');
});

test('resolveOperationalDate preserva a data operacional do T3 antes da meia-noite', () => {
  const date = new Date(2026, 2, 15, 1, 15);
  const resolved = resolveOperationalDate(date);
  assert.equal(resolved.getFullYear(), 2026);
  assert.equal(resolved.getMonth(), 2);
  assert.equal(resolved.getDate(), 14);
});

test('getOperationalDateKey produz chave no formato AAAA-MM-DD', () => {
  const date = new Date(2026, 2, 15, 1, 15);
  assert.equal(getOperationalDateKey(date), '2026-03-14');
});
