import test from 'node:test';
import assert from 'node:assert/strict';

import { toKg, toTon, calculateAccuracy } from '../js/utils/calculations.js';

test('toKg converte toneladas para quilogramas', () => {
  assert.equal(toKg(2, 't'), 2000);
  assert.equal(toKg(250, 'kg'), 250);
});

test('toTon converte quilogramas para toneladas', () => {
  assert.equal(toTon(2500, 'kg'), 2.5);
  assert.equal(toTon(3, 't'), 3);
});

test('calculateAccuracy retorna percentual de acurácia', () => {
  assert.equal(calculateAccuracy(990, 1000), 99);
  assert.equal(calculateAccuracy(120, 0), 0);
});
