import test from 'node:test';
import assert from 'node:assert/strict';

import { summarizeOperation, summarizeByOperation, summarizeByShift, buildImportHistorySummary } from '../js/utils/metrics.js';

test('summarizeOperation calcula soma de toneladas e SLA', () => {
  const summary = summarizeOperation([
    { toneladas: '1,5', slaStatus: 'dentro_do_sla' },
    { toneladas: '2,0', slaStatus: 'fora_do_sla' },
    { toneladas: '3,0', slaStatus: 'dentro_do_sla' }
  ], 'inbound');

  assert.equal(summary.totalRows, 3);
  assert.equal(summary.totalTon, 6.5);
  assert.equal(summary.slaRate, 66.66666666666666);
});

test('summarizeOperation calcula média de acurácia para inventário', () => {
  const summary = summarizeOperation([
    { acuracia: '99,2' },
    { acuracia: '98,8' }
  ], 'inventory');

  assert.equal(summary.accuracy, 99);
});

test('summarizeOperation preserva decimais numéricos e reconhece separadores locais', () => {
  const summary = summarizeOperation([
    { toneladas: 12.4 },
    { toneladas: '1.234,56' }
  ], 'inbound');

  assert.equal(summary.totalTon, 1246.96);
});

test('summarizeOperation calcula acurácia numérica sem multiplicar decimais por dez', () => {
  const summary = summarizeOperation([
    { acuracia: 98.3 },
    { acuracia: '99,7' }
  ], 'inventory');

  assert.equal(summary.accuracy, 99);
});

test('summarizeByOperation consolida totais por operação', () => {
  const summary = summarizeByOperation({
    inbound: [{ toneladas: '10', slaStatus: 'dentro_do_sla' }],
    outbound: [{ toneladas: '6', slaStatus: 'fora_do_sla' }],
    inventory: [{ acuracia: '98,5' }, { acuracia: '99,5' }]
  });

  assert.equal(summary.totalRows, 4);
  assert.equal(summary.totalTon, 16);
  assert.equal(summary.bestOperation.operation, 'inbound');
});

test('summarizeByShift identifica o turno de maior volume', () => {
  const summary = summarizeByShift([
    { turno: 'T1', toneladas: '4' },
    { turno: 'T3', toneladas: '3' },
    { turno: 'T3', toneladas: '2' }
  ]);

  assert.equal(summary.peakShift.turno, 'T3');
  assert.equal(summary.shifts.find((shift) => shift.turno === 'T3').totalRows, 2);
});

test('buildImportHistorySummary consolida histórico de importações', () => {
  const summary = buildImportHistorySummary([
    { validRows: 50, invalidRows: 10, duplicates: 4, updates: 2, status: 'validado' },
    { validRows: 30, invalidRows: 5, duplicates: 1, updates: 1, status: 'validado' }
  ]);

  assert.equal(summary.totalJobs, 2);
  assert.equal(summary.validRows, 80);
  assert.equal(summary.acceptanceRate, 84.21052631578947);
});
