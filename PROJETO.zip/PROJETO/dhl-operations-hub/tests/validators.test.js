import test from 'node:test';
import assert from 'node:assert/strict';

import {
  parseNumberBR,
  isRequired,
  validateDateBR,
  normalizeDedupKey
} from '../js/utils/validators.js';

test('parseNumberBR converte valores em formato brasileiro', () => {
  assert.equal(parseNumberBR('1.234,56'), 1234.56);
  assert.equal(parseNumberBR('0,25'), 0.25);
  assert.equal(parseNumberBR('abc'), null);
});

test('isRequired valida campos obrigatórios', () => {
  assert.equal(isRequired('   '), false);
  assert.equal(isRequired('ABC'), true);
  assert.equal(isRequired(0), true);
  assert.equal(isRequired(''), false);
});

test('validateDateBR aceita datas no padrão DD/MM/AAAA', () => {
  assert.equal(validateDateBR('03/12/2026'), true);
  assert.equal(validateDateBR('2026-12-03'), false);
});

test('normalizeDedupKey compõe uma chave determinística e normalizada', () => {
  assert.equal(normalizeDedupKey(['2026-03-14', 'DT-102', 'T1', 'VOLVO']), '2026-03-14|dt-102|t1|volvo');
  assert.equal(normalizeDedupKey(['', '  ABC  ', ' ']), 'abc');
});
