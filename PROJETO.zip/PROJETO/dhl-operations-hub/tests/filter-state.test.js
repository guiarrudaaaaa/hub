import test from 'node:test';
import assert from 'node:assert/strict';

import { writeFilterStateToHash } from '../js/utils/filter-state.js';

test('preserves the record search query when filter state changes', () => {
  const originalWindow = globalThis.window;
  let updatedHash = '';

  globalThis.window = {
    location: { hash: '#/inbound?q=DT-101&turno=T1' },
    history: {
      replaceState(_state, _title, url) {
        updatedHash = url;
      }
    }
  };

  try {
    assert.equal(
      writeFilterStateToHash({ year: '2026' }),
      '#/inbound?q=DT-101&turno=T1&year=2026'
    );
    assert.equal(updatedHash, '#/inbound?q=DT-101&turno=T1&year=2026');
  } finally {
    if (originalWindow === undefined) delete globalThis.window;
    else globalThis.window = originalWindow;
  }
});
