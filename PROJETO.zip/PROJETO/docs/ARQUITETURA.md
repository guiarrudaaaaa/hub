# Arquitetura do DHL Operations Hub 2026

## 1. Visão geral e análise crítica do briefing

O briefing descreve uma plataforma corporativa de inteligência operacional para um centro de distribuição com foco em Inbound, Outbound e Inventário, com dados importados de Excel e CSV, análise analítica avançada e requisitos de segurança e governança fortes. A proposta é ambiciosa e estrategicamente coerente com a operação logística, mas exige disciplina de arquitetura para evitar que o produto se transforme em um “dashboard bonito com dados frágeis”.

### Conclusão crítica

O projeto tem um potencial muito alto de valor de negócio, porque conecta dados operacionais reais a decisões de produtividade, SLA, acuracidade de estoque e gestão de desvios. Porém, o risco principal não está no frontend; está na qualidade dos dados, na rastreabilidade das importações, na segurança e na arquitetura de leitura/escrita no Firestore.

Os pontos mais críticos e que exigem decisão explícita são:

- a operação tem múltiplas dimensões temporais (data operacional, data de importação, turno, hora), e isso precisa ser centralizado em regras de calendário e agrupamento;
- a importação é o componente mais crítico e deve ser tratada como pipeline transacional e auditável, não como “upload + parse simples”;
- os dashboards de visão geral devem ler somente resumos agregados, e não registros detalhados, para manter custo e tempo de resposta controlados;
- o modelo de segurança do Firestore precisa ser realmente mais rígido do que o front-end, com permissões em regras e política de provisionamento de usuários;
- a combinação de dados operacionais, KPIs, regras determinísticas e visualizações avançadas exige uma arquitetura modular com funções puras e um modelo de dados bem explícito.

### Avaliação do briefing

O pedido é bem estruturado e traz os critérios certos para evitar “vibe coding”: visual premium, governança, segurança, dados reais, importação robusta, regras do Firestore, testes e documentação. Ele também exige um produto “autoral”, mas sem perder a necessidade de estar fundamentado em dados e arquitetura correta.

O maior ponto de força do briefing é a clareza dos requisitos de negócio e da governança de dados. O maior ponto de risco é a abrangência do escopo funcional, principalmente na etapa 4 (Inteligência) e na combinação de múltiplos gráficos complexos com importação e segurança. Isso só deve ser entregue em fases, com escopo de MVP bem definido.

## 2. Riscos principais e sua mitigação

### 2.1. Risco de excesso de escopo funcional

O app inclui uma grande quantidade de visuais analíticas avançadas, muitos tipos de gráfico e vários módulos. Isso pode diluir a entrega real, aumentar a chance de bugs e comprometer a qualidade de análise. Mitigação: tratar o projeto por fases, com um MVP focado em operação, importação, segurança e dashboard operacional suficiente para tomada de decisão.

### 2.2. Risco de dados inconsistentes na importação

Como o sistema aceita XLSX/CSV e o domínio da logística tem regras de data, turno, unidade, duplicidade e SLA, erros na importação podem gerar dados “vistosos” mas sem confiabilidade. Mitigação: pipeline em 12 etapas, validação de tipos, regras de negócio, chave de deduplicação determinística, registro de import_jobs e diffs de atualização.

### 2.3. Risco de custo e latência no Firestore

Se todos os gráficos forem alimentados por registros detalhados ou por consultas complexas com filtros e paginação ruim, o projeto aumentará custo e ficará lento. Mitigação: dashboard de visão geral apenas com resumos; detalhes em páginas de tabela com paginação por cursor; carga em lotes; cache local com cuidado.

### 2.4. Risco de segurança e privilégio

A plataforma opera com dados críticos e deve respeitar regras de acesso por perfil e auditoria de ações sensíveis. Não basta ocultar botões no frontend; precisa haver negação por padrão em Firestore Rules. Mitigação: papéis explícitos, provisionamento manual, App Check, regras de validação estritas, log imutável e bootstrap seguro para primeiro admin.

### 2.5. Risco de arquitetura tecnológica incompatível com os requisitos

O requisito de “sem framework, sem build obrigatório, Web Worker, ECharts e Firebase” é compatível, mas exige um código bem organizado e uma separação de responsabilidades clara. Mitigação: arquitetura de front-end modular, store simples com eventos, componentes pequenos, utilitários puros e camadas de serviço bem definidas.

## 3. Decisões de arquitetura

### 3.1. Modelo de front-end

- Aplicação front-end estática com HTML semântico, CSS modular e JavaScript ES2022.
- Router por hash sem recarga.
- Estrutura de módulos e componentes com responsabilidades bem definidas.
- Store simples com eventos, em vez de estado global caótico ou framework reativo.
- Web Worker para leitura e parse de XLSX/CSV, evitando travamento de UI.
- ECharts para visualizações analíticas avançadas.
- Ícones SVG locais, sem dependência de bibliotecas volumosas para UI.

### 3.2. Modelo de dados e persistência

- Firestore como fonte de verdade operacional e agregada.
- Dois níveis de dados:
  1. detalhados: `inbound_records`, `outbound_records`, `inventory_records`;
  2. agregados: `daily_summaries`, `monthly_summaries`, `audit_log`, `settings`.
- Dashboard e visões gerais lêem somente resumos; detalhamento exige consulta diretamente à coleção detalhada, paginada e filtrada.
- Resumos diários/mensais gerados no cliente durante importação e persistidos em transação por operação.
- Inventário: guardar apenas divergências relevantes e resumos de acuracidade, em vez de duplicar o estoque completo. Essa decisão reduz custo e mantém utilidade operacional.

### 3.3. Modelo de importação

A importação será um pipeline completo, não um simples upload. O fluxo ideal é:

1. seleção de operação;
2. escolha do arquivo;
3. leitura no navegador via worker;
4. inspeção das primeiras linhas;
5. mapeamento com sugestões e perfis salvos;
6. validação por tipo, faixa, formato e obrigatoriedade;
7. deduplicação determinística;
8. resumos de válidos/inválidos/duplicados/atualizações;
9. confirmação explícita;
10. gravação em lotes (`<= 400` registros por batch);
11. acompanhamento e retomo;
12. registro em `import_jobs`.

A garantia central aqui é a idempotência. Reimportar o mesmo arquivo não deve duplicar registros, e a atualização de registros existentes deve exigir confirmação explícita e diff de campos.

### 3.4. Segurança e governança

- autenticação via Firebase Authentication com email/senha;
- provisionamento via usuários autorizados (`allowed_users`), nunca auto-cadastro;
- papéis: `admin`, `analista`, `visualizador` em `users/{uid}`;
- regras do Firestore negando por padrão;
- App Check obrigatório;
- logs de auditoria para login, importação, atualização, reversão, papel e exportação;
- headers HTTP restritivos e CSP rígida no Hosting;
- sanitização de todas as entradas e exportações, evitando CSV/formula injection.

## 4. Modelo de dados no Firestore

### 4.1. Coleções principais

#### `inbound_records`

Campos representativos:

- `recordId` (determinado por hash de chave única)
- `importId`
- `sourceFile`
- `sourceRow`
- `importedBy`
- `createdAt`
- `updatedAt`
- `dedupKey`
- `schemaVersion`
- `dataOperacional`
- `dt`
- `turno`
- `veiculo`
- `transportadora`
- `checkIn`
- `inicioProcesso`
- `finalizacao`
- `tempoProcessoMin`
- `toneladas`
- `pallets`
- `unidades`
- `statusTmp`
- `motivoAtraso`
- `slaStatus`
- `metadata` (campos extras limitados e validados)

#### `outbound_records`

Campos equivalentes ao módulo outbound, incluindo:

- `inicioOperacao`
- `fimOperacao`
- `tempoTotalMin`
- `toneladas`
- `volumes`
- `qtdSkus`
- `statusTmp`
- `ocorrencias`
- `justificativaCortes`
- `operacao` (`batida` ou `paletizada`)

#### `inventory_records`

- `sku`
- `descricao`
- `endereco`
- `qtdSistemica`
- `qtdFisica`
- `divergencia`
- `unidade`
- `status`
- `motivoAjuste`
- `acuracia`
- `tipoAjuste` (`positivo`, `negativo`, `avaria`, `bloqueado`)

Observação importante: para inventário, o modelo mais econômico não é armazenar “todo o estoque completo” em registros detalhados; o melhor desenho é guardar:

- registros detalhados somente de divergências e ajustes relevantes;
- resumos de acuracidade por SKU/endereço e por período;
- métricas resumidas calculadas no cliente durante a importação e gravadas em `daily_summaries` e `monthly_summaries`.

Isso reduz custo, mantém rastreabilidade e não compromete o reporting executivo.

#### `import_jobs`

- `importId`
- `operation`
- `status` (`em_andamento`, `validando`, `concluido`, `parcial`, `falhou`, `revertido`)
- `sourceFile`
- `uploadedBy`
- `startedAt`
- `finishedAt`
- `totalRows`
- `validRows`
- `invalidRows`
- `duplicates`
- `updates`
- `batchesCompleted`
- `pendingBatches`
- `lastError`
- `rollbackEnabled`

#### `users`

- `uid`
- `email`
- `status` (`ativo`, `inativo`, `pendente_verificacao`)
- `role` (`admin`, `analista`, `visualizador`)
- `mfaEnabled`
- `lastLoginAt`
- `createdAt`
- `updatedAt`

#### `settings`

- `metaInbound`
- `metaOutbound`
- `metaAcuracia`
- `formulaAcuracia`
- `turnos`
- `fusoHorario`
- `configuracoesImportacao`

#### `monthly_summaries`

- `monthKey` (`YYYY-MM`)
- `operation`
- `totals`
- `slaPct`
- `tmpAvg`
- `acuracia`
- `divergencias`
- `variacaoMesAnterior`

#### `daily_summaries`

- `dayKey` (`YYYY-MM-DD`)
- `operation`
- `cargas`
- `toneladas`
- `pallets`
- `slaPct`
- `tmpAvg`
- `variacaoDiaAnterior`

#### `audit_log`

- `auditId`
- `userId`
- `action`
- `entity`
- `entityId`
- `details`
- `createdAt`

#### `mapping_profiles`

- `profileId`
- `operation`
- `layoutName`
- `columnMap`
- `validationRules`
- `createdBy`
- `createdAt`
- `updatedAt`

### 4.2. Chaves de deduplicação e idempotência

A plataforma exige determinismo total. Cada módulo deve ter sua própria chave de negócio para cálculo do hash de deduplicação.

Exemplo de regra:

- Inbound: `dataOperacional + DT + turno + veiculo + checkIn`
- Outbound: `dataOperacional + DT + turno + veiculo + inicioOperacao`
- Inventário: `dataOperacional + SKU + endereco + unidade + tipoAjuste`

A chave final deve ser gerada via Web Crypto (SHA-256) do valor normalizado, e o documento terá `dedupKey` e `recordId` derivados dela. Isso garante idempotência e evita duplicação por reimportação do mesmo arquivo.

### 4.3. Estratégia de leitura por provas de custo

A análise de custo e volume do Firestore ocorre da seguinte forma:

- recuperação de visão geral: somente `daily_summaries` e `monthly_summaries`;
- leitura de detalhes: somente por tabela filtrada, paginada por cursor, 50 registros por página;
- leitura de usuários e permissões: apenas quando necessário em autenticação e controle de acesso;
- auditoria: escrita append-only, leitura controlada.

Esse desenho minimiza leitura de documentos detalhados, reduz custo e permite responder a dashboards de operação rapidamente.

## 5. Estratégia de importação em detalhes

### 5.1. Arquitetura da importação

A leitura do arquivo ocorrerá em um Web Worker para não bloquear a thread principal. O fluxo será:

- `parse-worker.js` recebe o arquivo e o tipo (`.xlsx` ou `.csv`);
- uso da biblioteca SheetJS oficial via CDN com integrity e crossorigin;
- leitura em chunks/streaming, conforme o tamanho do arquivo;
- geração de uma visão das primeiras linhas para inspeção e mapeamento;
- inferência de colunas por similaridade de nomes e perfis salvos;
- validação por regras de negócio e datatypes;
- deduplicação e cálculo de diferenciais de atualização;
- processamento em lotes com retry e backoff.

### 5.2. Mapeamento e validação

O mapeamento deve possuir:

- detecção automática por similaridade semântica;
- validação de tipos e campos obrigatórios;
- suporte a data em `dd/mm/aaaa` e números com vírgula decimal;
- regras de faixa plausível e de unidade;
- alertas para “toneladas ≠ quilogramas” com exigência de confirmação do usuário;
- validação de turno/T3 e regra da virada de meia-noite.

### 5.3. Duplicidade e atualização

- duplicados são detectados pela `dedupKey` e marcados no relatório;
- atualização de registro existente exige confirmação explícita do usuário;
- diff campo a campo deve ser visualizado antes da gravação;
- atualização deve preservar rastro (`updatedAt`, `importId`, `sourceFile`, `sourceRow`);
- reimportação do mesmo arquivo deve ser idempotente, não duplicando registros.

### 5.4. Tratamento de falhas e recuperação

- para cada lote: `status` e `retryCount`;
- progressos salvos em `import_jobs`;
- pausa/retomada de lotes;
- backoff exponencial simples em falhas temporárias;
- possibilidade de reversão de importação por admin com base em `importId`;
- nenhum dado deve ser perdido: job registra o que foi concluído e o restante fica pendente.

### 5.5. Reversão e rastreabilidade

A reversão deve funcionar com base em `importId`, e não por “apagamento de arquivo”. Isso mantém integridade e rastreabilidade. Todo registro deve guardar origem e auditoria. O processo deve ser restrito a perfil admin e registrar ação em `audit_log`.

## 6. Regras de negócio centrais

### 6.1. Regra de turno e data operacional

Os turnos são:

- T1: 05:30–13:40
- T2: 13:40–22:00
- T3: 22:00–05:30 do dia seguinte

A data operacional de um registro cuja operação ocorreu no T3 após a meia-noite precisa pertencer ao dia em que o turno começou. Essa regra deve ser centralizada em `date-utils.js` e não repetida no código de módulo. Isso reduz inconsistência e facilita testes automatizados.

### 6.2. Unidades e conversão

- toneladas e quilogramas devem ser tratadas como unidades distintas;
- a conversão `kg ↔ t` deve ser explícita e validada;
- na importação, a unidade inadequada deve exigir confirmação explícita antes do mapeamento final.

### 6.3. Nota sobre DT

Uma DT não é uma movimentação individual. A mesma DT pode ocorrer em múltiplas datas e turnos distintos. Isso impacta a deduplicação: a chave de negócio deve refletir a operação e o contexto temporal, e não apenas a DT isoladamente.

## 7. Segurança e conformidade

### 7.1. Autenticação e identidade

- cadastro público desabilitado;
- usuários cadastrados apenas por admin manual em console ou por processo provisionado seguro;
- email obrigatório e verificação de email;
- política de senha forte;
- logout por inatividade;
- MFA/TOTP quando disponível no plano.

### 7.2. Modelos de risco e controes

O projeto deve considerar a matriz STRIDE, com foco em:

- Spoofing: autenticação forte, identidade imutável e provisionamento controlado;
- Tampering: regras de Firestore e validação de campos extras;
- Repudiation: audit log completo e não modificável;
- Information disclosure: regras de leitura, CSP e limitando o conteúdo de logs;
- Denial of service: limites de tamanho, upload, linhas e lotes, paginação e validação;
- Elevation of privilege: papéis e regras no Firestore. 

### 7.3. Regras no Firestore

Regras devem seguir as seguintes premissas:

- negar por padrão;
- `visualizador`: leitura apenas;
- `analista`: leitura + criar/atualizar registros e importações;
- `admin`: tudo, incluindo ajuste de metas, reversão e gestão de usuários;
- proibir campos extras;
- validar `dedupKey`, datas, faixas numéricas e tipos;
- `createdAt`, `importedBy`, `importId` são imutáveis;
- `updatedAt` deve ser sempre `request.time`;
- `audit_log` somente `create` e append-only;
- delete direto bloqueado fora de admin.

### 7.4. App Check e hosting

- App Check ativado para Firestore e Auth;
- hosting com headers de segurança reforçados, incluindo CSP restritiva sem `unsafe-inline`/`unsafe-eval`;
- `frame-ancestors 'none'`; `Permissions-Policy` e `Referrer-Policy` rigorosos;
- uso de `integrity` em recursos externos, com versões fixas.

### 7.5. Front-end seguro

- nunca usar `innerHTML` com entrada de planilha ou usuário;
- usar `textContent`, templates seguros e escape de valores;
- sanitização em CSV/XLSX exportados;
- prefixar `=`, `+`, `-`, `@` em exportação para prevenir fórmula injection;
- mensagens genéricas de erro para o usuário;
- detalhe técnico apenas em logs locais.

## 8. MVP e escopo realista

### 8.1. MVP recomendado

A fase inicial deve entregar com segurança:

- autenticação e RBAC funcional;
- router por hash e navegação por módulo;
- layout dark executive e filtros globais persistentes;
- análise operacional básica por operação (Inbound/Outbound/Inventário);
- importação funcional com wizard, mapeamento e validação;
- deduplicação e import_jobs;
- resumos diários/mensais e dashboards executivos;
- tabelas com paginação e filtros;
- auditoria e regras do Firestore;
- testes essenciais de regras e utilitários de negócio.

### 8.2. Fora do MVP

- gráficos altamente avançados em todas as operações no início;
- Modo TV e exportação complexa pode entrar em outra fase, desde que a base funcional esteja estável;
- múltiplos perfis de usuário e regras específicas aprofundadas podem ser incorporados depois da base estar sólida;
- excesso de customização de dashboard sem necessidade de negócio deve ser evitado.

## 9. Plano por fases

### Fase 1 — Fundação

- arquitetura e documentação definitiva;
- design system e tokens;
- layout principal, sidebar, router e navegação;
- Auth com Firebase;
- bootstrap de regras base e configuração de hosting;
- estrutura de módulos e utilitários.

### Fase 2 — Dados e importação

- modelagem de Firestore;
- pipeline de importação;
- validação e mapeamento de colunas;
- deduplicação e `import_jobs`;
- resumos diários e mensais;
- histórico de importações e reversão.

### Fase 3 — Operações

- módulos Inbound, Outbound e Inventário;
- filtros globais, KPIs e tabelas;
- páginas de detalhe e registros;
- ranking, status e ações de operação.

### Fase 4 — Inteligência e visão geral

- Central de Indicadores;
- gráficos avançados com ECharts;
- Leitura Automática por regras determinísticas;
- Mode TV e exportação; 
- drill-down por interações.

### Fase 5 — Refinamento, custo e publicação

- otimização de custo do Firestore;
- revisão final de segurança e auditoria;
- acessibilidade e responsividade;
- testes e publicação no Firebase Hosting.

## 10. Estratégia de índices do Firestore

Para manter custo e desempenho, os índices compostos devem cobrir consultas reais do app e não tentar indexar tudo. Os principais padrões são:

- `operation + dataOperacional`;
- `operation + turno + dataOperacional`;
- `operation + statusTmp + dataOperacional`;
- `operation + transportadora + dataOperacional`;
- `operation + dt + dataOperacional`;
- `sku + dataOperacional` para inventário;
- `importId + operation` em registros detalhados;
- `monthKey + operation` em resumos mensais;
- `dayKey + operation` em resumos diários;
- `createdAt` em `audit_log` para auditoria histórica.

A estrutura exata deve estar em `firestore.indexes.json`, com índices compostos e sem índice genérico excessivo.

## 11. Decisão de arquitetura de dados e performance

### 11.1. Por que resumos em vez de leitura direta de detalhes?

A resposta é simples: os dashboards de visão geral precisam ser confiáveis, rápidos e baratos. Consultar registros detalhados para cada KPI e cada gráfico multiplicaria consumo de leitura, aumentaria latência e geraria custo desnecessário.

### 11.2. Quando detalhar?

Somente em páginas de tabela ou análise local e filtrada. Esse desenho respeita a natureza do produto: dados de execução operacionais devem ser detalhados em contexto, e visão executiva deve ser agregada.

### 11.3. Cache local

A aplicação pode manter dados resumidos em IndexedDB ou cache local, mas sem comprometer segurança e sem criar estado ambíguo. A regra é: cache é somente para acelerar leitura já permitida; a fonte de verdade continua sendo o Firestore.

## 12. Observações finais

Este projeto é viável, mas só será bem-sucedido se a arquitetura priorizar três pilares: 1) integridade dos dados, 2) segurança por design, 3) leitura agregada para performance e custo. A parte visual e analítica será forte, mas o diferencial real vai estar em uma base confiável, rastreável e governada.

A arquitetura acima respeita os requisitos do briefing, mantém a aplicação estática e compatível com Firebase, e define uma base sólida para evolução faseada sem criar risco de colapso técnico.

## Dúvidas bloqueantes (máximo 5)

1. O cliente confirma que a importação deve aceitar apenas arquivos de operação única por vez, ou há necessidade de múltiplas operações em um mesmo arquivo?
2. Existe um catálogo oficial de unidades e abreviações para toneladas/quilogramas, pallets, fardos e volumes que a aplicação deve padronizar no mapeamento?
3. O ambiente de produção terá uma política de provisionamento de usuários centralizada por admin ou será necessário suporte pré-definido por e-mail em console do Firebase?
4. Há uma regra corporativa específica para acurácia de inventário (ex.: fórmula do tipo `(qtd Física / qtd Sistêmica)` ou uma regra por SKU/endereço) que deve ser rígida no sistema?
5. O cliente deseja que a reversão de importação seja aplicada somente ao lote mais recente ou a qualquer `importId` histórico, inclusive com possibilidade de reprocessamento parcial?

Aguardando aprovação para iniciar a implementação da Fase 1.
